#!/usr/bin/env node

const DAY_MS = 24 * 60 * 60 * 1000;
const BACKFILL_STEP_MS = 15 * 60 * 1000;
const MAX_FEEDS_PER_BATCH = 60;
const MIN_UPDATE_INTERVAL_SECONDS = 15;

function parseArguments(argv) {
    const options = { interval: 20, scenario: "normal", backfill: 0 };
    for (let index = 0; index < argv.length; index += 1) {
        const argument = argv[index];
        if (argument === "--help" || argument === "-h") { options.help = true; continue; }
        if (!["--host", "--key", "--interval", "--scenario", "--backfill"].includes(argument)) {
            throw new Error(`Unknown option: ${argument}`);
        }
        const value = argv[index + 1];
        if (!value || value.startsWith("--")) throw new Error(`${argument} requires a value.`);
        options[argument.slice(2)] = value;
        index += 1;
    }
    if (options.help) return options;
    if (!options.host || !options.key) throw new Error("Both --host and --key are required.");
    options.interval = Number(options.interval);
    options.backfill = Number(options.backfill);
    if (!Number.isFinite(options.interval) || options.interval < MIN_UPDATE_INTERVAL_SECONDS) {
        throw new Error(`--interval must be at least ${MIN_UPDATE_INTERVAL_SECONDS} seconds (the API rate limit).`);
    }
    if (!Number.isInteger(options.backfill) || options.backfill < 0) throw new Error("--backfill must be a non-negative number of days.");
    if (!["normal", "dimming", "flicker", "failure", "always-on"].includes(options.scenario)) {
        throw new Error("--scenario must be normal, dimming, flicker, failure, or always-on.");
    }
    try {
        const parsedHost = new URL(options.host);
        if (!["http:", "https:"].includes(parsedHost.protocol)) throw new Error();
        options.endpoint = parsedHost.pathname.replace(/\/$/, "").endsWith("/api/update")
            ? parsedHost
            : new URL(`${parsedHost.pathname.replace(/\/$/, "")}/api/update`, parsedHost.origin);
    } catch {
        throw new Error("--host must be an HTTP(S) origin or /api/update URL.");
    }
    return options;
}

function istParts(date) {
    const parts = new Intl.DateTimeFormat("en-GB", {
        timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit",
        hour: "2-digit", minute: "2-digit", hourCycle: "h23"
    }).formatToParts(date);
    return Object.fromEntries(parts.map(part => [part.type, part.value]));
}

const dailySchedules = new Map();
function shouldBeOn(date, scenario) {
    if (scenario === "always-on" || scenario === "failure") return true;
    const parts = istParts(date);
    const dayKey = `${parts.year}-${parts.month}-${parts.day}`;
    if (!dailySchedules.has(dayKey)) {
        dailySchedules.set(dayKey, {
            start: 9 * 60 + Math.round((Math.random() * 30) - 15),
            end: 17 * 60 + Math.round((Math.random() * 30) - 15)
        });
    }
    const minuteOfDay = Number(parts.hour) * 60 + Number(parts.minute);
    const schedule = dailySchedules.get(dayKey);
    return minuteOfDay >= schedule.start && minuteOfDay < schedule.end;
}

function makeReading(date, options, simulationEnd, failureStartedAt) {
    const on = shouldBeOn(date, options.scenario);
    let lux;
    if (!on) {
        lux = Math.round(Math.random() * 20);
    } else if (options.scenario === "failure" && date.getTime() >= failureStartedAt) {
        lux = Math.round(Math.random() * 5);
    } else {
        let brightness = 400 + (Math.random() * 40 - 20);
        if (options.scenario === "dimming") {
            const ageDays = Math.max(0, (simulationEnd - date.getTime()) / DAY_MS);
            brightness *= 1 - Math.min(0.25, ageDays / 28 * 0.25);
        }
        lux = brightness + (Math.random() * 20 - 10);
        if (options.scenario === "flicker" && Math.random() < 0.14) lux = 15 + Math.random() * 65;
        lux = Math.round(Math.max(0, lux));
    }
    return { field1: lux, field2: on ? "ON" : "OFF" };
}

function delay(milliseconds) { return new Promise(resolve => setTimeout(resolve, milliseconds)); }

function formatError(response, body) {
    const code = response.headers.get("X-Error-Code");
    const encodedMessage = response.headers.get("X-Error-Message");
    const message = encodedMessage ? decodeURIComponent(encodedMessage) : body;
    return `${response.status}${code ? ` ${code}` : ""}: ${message || "request rejected"}`;
}

async function sendGet(endpoint, key, reading) {
    const url = new URL(endpoint);
    url.searchParams.set("api_key", key);
    url.searchParams.set("field1", String(reading.field1));
    url.searchParams.set("field2", reading.field2);
    const response = await fetch(url, { method: "GET" });
    const body = (await response.text()).trim();
    if (!response.ok || !/^\d+$/.test(body) || Number(body) < 1) throw new Error(formatError(response, body));
    console.log(`${new Date().toISOString()} GET entry_id=${body} lux=${reading.field1} state=${reading.field2}`);
}

async function sendBatch(endpoint, key, feeds) {
    const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ api_key: key, feeds })
    });
    const body = (await response.text()).trim();
    if (response.status === 429) return false;
    if (!response.ok || !/^\d+$/.test(body) || Number(body) < 1) throw new Error(formatError(response, body));
    console.log(`Backfill batch stored ${feeds.length} feeds; last entry_id=${body}.`);
    return true;
}

async function backfill(options, now) {
    if (!options.backfill) return now;
    const start = now - options.backfill * DAY_MS;
    const failureStartedAt = options.scenario === "failure" ? start + (now - start) * 0.7 : Infinity;
    const feeds = [];
    for (let timestamp = start; timestamp <= now; timestamp += BACKFILL_STEP_MS) {
        const date = new Date(timestamp);
        feeds.push({ created_at: date.toISOString(), ...makeReading(date, options, now, failureStartedAt) });
    }
    console.log(`Backfilling ${feeds.length} samples across ${options.backfill} days at 15-minute intervals.`);
    for (let offset = 0; offset < feeds.length; offset += MAX_FEEDS_PER_BATCH) {
        const batch = feeds.slice(offset, offset + MAX_FEEDS_PER_BATCH);
        let stored = false;
        for (let attempt = 0; attempt < 3 && !stored; attempt += 1) {
            if (offset > 0 || attempt > 0) await delay(options.interval * 1000);
            stored = await sendBatch(options.endpoint, options.key, batch);
        }
        if (!stored) throw new Error("Backfill was rate limited three times; try again after the channel rate limit clears.");
    }
    return now;
}

function help() {
    console.log(`Usage: node tools/simulator.js --host https://your-domain.example --key WRITE_KEY [options]

Options:
  --host       Site origin or full /api/update URL
  --key        Channel write API key
  --interval   Live update interval in seconds (default 20; minimum 15)
  --scenario   normal | dimming | flicker | failure | always-on (default normal)
  --backfill   Generate this many days of 15-minute history before live mode

Live telemetry uses the ESP32-compatible GET request. Historical backfill uses
the API's existing POST feeds batch endpoint and waits one configured interval
between batches to comply with channel rate limiting.`);
}

async function main() {
    let options;
    try { options = parseArguments(process.argv.slice(2)); }
    catch (error) { console.error(error.message); process.exitCode = 2; return; }
    if (options.help) { help(); return; }
    if (typeof fetch !== "function") { console.error("Node.js 18 or newer is required (built-in fetch)."); process.exitCode = 2; return; }

    const startedAt = Date.now();
    await backfill(options, startedAt);
    const failureStartedAt = options.scenario === "failure" ? startedAt + 60 * 1000 : Infinity;
    console.log(`Simulator running (${options.scenario}) at ${options.interval}s intervals. Press Ctrl+C to stop.`);
    let running = true;
    process.once("SIGINT", () => { running = false; console.log("\nSimulator stopped."); });
    while (running) {
        const now = Date.now();
        try {
            await sendGet(options.endpoint, options.key,
                makeReading(new Date(now), options, startedAt, failureStartedAt));
        } catch (error) {
            console.error(`Simulator request failed: ${error.message}`);
            if (!/429 RATE_LIMITED/.test(error.message)) { process.exitCode = 1; break; }
        }
        if (running) await delay(options.interval * 1000);
    }
}

main().catch(error => { console.error(error.message); process.exitCode = 1; });
