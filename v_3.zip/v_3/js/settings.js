import { getCurrentChannelId, getDevices, getUserSettings, saveActiveChannelId, saveUserSettings } from "./firebase-service.js";

document.addEventListener("DOMContentLoaded", async () => {
    const saveButton = document.getElementById("saveSettings");
    const message = document.getElementById("settingsMessage");
    const controls = {
        applicationName: document.getElementById("applicationName"), timezone: document.getElementById("timezone"),
        dateFormat: document.getElementById("dateFormat"), alertNotifications: document.getElementById("alertNotifications"),
        anomalyNotifications: document.getElementById("anomalyNotifications"), offlineNotifications: document.getElementById("offlineNotifications"),
        activeChannelSetting: document.getElementById("activeChannelSetting")
    };
    if (!saveButton || !message || !controls.activeChannelSetting) return;
    try {
        const settings = await getUserSettings();
        const active = await getCurrentChannelId();
        const channels = (await getDevices()).filter(item => item.channelType === "channel");
        controls.activeChannelSetting.innerHTML = `<option value="">All channels</option>${channels.map(channel => `<option value="${escapeHtml(channel.id)}">${escapeHtml(channel.name || channel.deviceName)}</option>`).join("")}`;
        controls.activeChannelSetting.value = active;
        Object.entries(controls).forEach(([key, control]) => {
            if (control && settings[key] !== undefined) {
                if (control.type === "checkbox") control.checked = Boolean(settings[key]);
                else if (key !== "activeChannelSetting") control.value = settings[key];
            }
        });
        if (controls.timezone && !settings.timezone) controls.timezone.value = localStorage.getItem("iot-insight-timezone") || "Asia/Kolkata";
    } catch (error) { show(error.message, true); }
    saveButton.addEventListener("click", async () => {
        const settings = Object.fromEntries(Object.entries(controls).filter(([, control]) => control).map(([key, control]) => [key, control.type === "checkbox" ? control.checked : control.value]));
        try {
            await saveUserSettings(settings);
            await saveActiveChannelId(controls.activeChannelSetting.value);
            if (controls.timezone) localStorage.setItem("iot-insight-timezone", controls.timezone.value);
            show("Settings saved to your account.");
        } catch (error) { show(error.message, true); }
    });
    function show(text, error = false) { message.textContent = text; message.classList.remove("hidden"); message.classList.toggle("error", error); }
});
function escapeHtml(value) { return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;"); }
