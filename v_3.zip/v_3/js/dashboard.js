import { loadFirebaseData, showDataError } from "./firebase-data.js";
import { firebaseConfig, getCurrentChannelId, getUserAlerts, saveActiveChannelId, subscribeToTemperatureReadings, subscribeToUserMonitoring, subscribeToUserAlerts, subscribeToUserPreferences } from "./firebase-service.js";
import { createTimeSeriesChart, addChartControls } from "./chart-factory.js";

document.addEventListener("DOMContentLoaded", async () => {
    let data;
    try { data = await loadFirebaseData(); } catch (error) { showDataError(error); return; }
    const { readings = [], devices = [], parameters = [] } = data;
    let currentReadings = readings;
    let currentDevices = devices;
    let allLiveReadings = readings;
    const channelSelect = document.getElementById("activeChannelSelect");
    if (channelSelect) {
        const channels = devices.filter(device => device.channelType === "channel");
        channelSelect.innerHTML = `<option value="">All channels</option>${channels.map(channel => `<option value="${escapeHtml(channel.id)}">${escapeHtml(channel.name || channel.deviceName)}</option>`).join("")}`;
        try { channelSelect.value = await getCurrentChannelId(); } catch (error) { console.warn("Could not load active channel", error); }
        channelSelect.addEventListener("change", async () => {
            try {
                await saveActiveChannelId(channelSelect.value);
                const activeId = channelSelect.value;
                currentReadings = activeId ? allLiveReadings.filter(reading => reading.channelId === activeId || reading.deviceId === activeId) : allLiveReadings;
                currentDevices = activeId ? devices.filter(device => device.id === activeId || device.deviceId === activeId) : devices;
                document.getElementById("dashboardSimulatedBadge")?.classList.toggle("hidden", !currentDevices.some(device => device.isSimulated));
                renderParameterChart(currentReadings, "");
                updateLiveSummary(currentReadings, currentDevices);
            } catch (error) { setTelemetryStatus(error.message); }
        });
        try {
            const unsubscribe = await subscribeToUserPreferences(preferences => {
                if (preferences.activeChannelId && [...channelSelect.options].some(option => option.value === preferences.activeChannelId)) channelSelect.value = preferences.activeChannelId;
                else if (!preferences.activeChannelId) channelSelect.value = "";
            }, error => console.error("Active channel preference listener failed", error));
            window.addEventListener("pagehide", unsubscribe, { once: true });
        } catch (error) { console.warn("Active channel preference listener unavailable", error); }
    }
    currentDevices = channelSelect?.value ? devices.filter(device => device.id === channelSelect.value || device.deviceId === channelSelect.value) : devices;
    currentReadings = channelSelect?.value ? readings.filter(reading => reading.channelId === channelSelect.value || reading.deviceId === channelSelect.value) : readings;
    document.getElementById("dashboardSimulatedBadge")?.classList.toggle("hidden", !currentDevices.some(device => device.isSimulated));
    window.iotParameterUnits = Object.fromEntries(parameters.map(item => [item.parameterName, item.unit || ""]));
    const selectedChannelId = channelSelect?.value;
    const initialReadings = currentReadings;
    const field = initialReadings.find(reading => Number.isFinite(Number(reading.value)))?.parameterName || initialReadings[0]?.parameterName;
    const stateReadings = initialReadings.filter(reading => reading.parameterName === field).sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

    const stats = document.querySelectorAll(".dashboard-stat");
    const alertCount = document.getElementById("activeAlertsCount");
    try {
        const alerts = await getUserAlerts();
        const openCount = alerts.filter(alert => alert.status === "open" && (!channelSelect?.value || alert.channelId === channelSelect.value || alert.deviceId === channelSelect.value)).length;
        if (alertCount) alertCount.textContent = openCount;
    } catch (error) { console.warn("Could not load alert count", error); }
    try {
        const unsubscribe = await subscribeToUserAlerts(alerts => {
            if (alertCount) alertCount.textContent = alerts.filter(alert => alert.status === "open" && (!channelSelect?.value || alert.channelId === channelSelect.value || alert.deviceId === channelSelect.value)).length;
        }, error => console.error("Alert count subscription failed", error));
        window.addEventListener("pagehide", unsubscribe, { once: true });
    } catch (error) { console.warn("Alert count subscription unavailable", error); }

    updateStat(stats[0], String(currentDevices.length), "Firebase devices");
    updateStat(stats[1], String(new Set(currentReadings.map(reading => reading.parameterName)).size), "Imported parameters");
    updateStat(stats[2], String(currentReadings.length), "Last 24 hours");
    updateStat(stats[3], alertCount?.textContent || "0", "Open alerts");
    const activeAlertsStat = stats[3]?.closest(".stat-card")?.querySelector(".stat-change");
    if (activeAlertsStat) activeAlertsStat.textContent = "Open alerts";
    if (stateReadings.length) {
        const latest = stateReadings[stateReadings.length - 1];
        setText("currentLightState", latest.state || "Available");
        setText("lightStatus", latest.state || "Available");
        setText("lightValue", `${field}: ${latest.rawValue ?? latest.value}`);
        setText("latestReading", `${field} at ${formatTime(latest.timestamp)}`);
        setText("lastUpdated", formatTime(latest.timestamp));
        setText("statusUpdated", formatTime(latest.timestamp));
        updateInsights(stateReadings);
    }

    const dashboardFieldSelect = document.getElementById("dashboardFieldSelect");
    const fields = [...new Set(currentReadings.map(reading => reading.parameterName))];
    if (dashboardFieldSelect) {
        dashboardFieldSelect.innerHTML = `<option value="">All parameters</option>${fields.map(fieldName => `<option value="${escapeHtml(fieldName)}">${escapeHtml(fieldName)}</option>`).join("")}`;
        dashboardFieldSelect.addEventListener("change", () => renderParameterChart(currentReadings, dashboardFieldSelect.value));
    }
    renderParameterChart(currentReadings, "");

    setTelemetryStatus(data.source === "ThingSpeak" ? "Showing imported ThingSpeak data" : "Showing imported Firebase data");
    if (firebaseConfig.databaseURL) try {
        const unsubscribe = await subscribeToTemperatureReadings(liveReadings => {
            if (dashboardFieldSelect) {
                dashboardFieldSelect.value = "";
                dashboardFieldSelect.disabled = true;
            }
            if (!liveReadings.length) {
                setTelemetryStatus("Connected to Realtime Database; waiting for sensor readings");
                return;
            }
            const temperatureReadings = liveReadings.map(reading => ({
                parameterName: "Temperature",
                timestamp: reading.time,
                value: reading.value
            }));
            renderParameterChart(temperatureReadings, "Temperature");
            updateInsights(temperatureReadings);
            const latest = temperatureReadings[temperatureReadings.length - 1];
            setText("currentLightState", `${latest.value} °C`);
            setText("lightValue", `Temperature: ${latest.value} °C`);
            setText("latestReading", `Temperature at ${formatTime(latest.timestamp)}`);
            setText("lastUpdated", formatTime(latest.timestamp));
            setText("statusUpdated", formatTime(latest.timestamp));
            setTelemetryStatus(`Live Realtime Database · ${liveReadings.length} latest readings`);
        }, error => {
            console.error("Realtime temperature subscription failed.", error);
            setTelemetryStatus(`Realtime Database error: ${error.message}`);
        });
        window.addEventListener("pagehide", unsubscribe, { once: true });
    } catch (error) {
        console.error("Realtime temperature subscription could not start.", error);
        setTelemetryStatus(`${error.message} Showing imported readings instead.`);
    }

    try {
        const unsubscribe = await subscribeToUserMonitoring(snapshot => {
            const activeId = channelSelect?.value;
            allLiveReadings = snapshot.readings;
            currentReadings = activeId ? allLiveReadings.filter(reading => reading.channelId === activeId || reading.deviceId === activeId) : allLiveReadings;
            currentDevices = snapshot.devices;
            if (channelSelect) {
                const selected = channelSelect.value;
                channelSelect.innerHTML = `<option value="">All channels</option>${currentDevices.filter(device => device.channelType === "channel").map(channel => `<option value="${escapeHtml(channel.id)}">${escapeHtml(channel.name || channel.deviceName)}</option>`).join("")}`;
                channelSelect.value = selected;
            }
            currentDevices = channelSelect?.value ? snapshot.devices.filter(device => device.id === channelSelect.value || device.deviceId === channelSelect.value) : snapshot.devices;
            document.getElementById("dashboardSimulatedBadge")?.classList.toggle("hidden", !currentDevices.some(device => device.isSimulated));
            updateStat(stats[0], String(currentDevices.length), "Firebase devices");
            updateStat(stats[1], String(new Set(currentReadings.map(reading => reading.parameterName)).size), "Configured parameters");
            updateStat(stats[2], String(currentReadings.length), "Stored readings");
            const fields = [...new Set(currentReadings.map(reading => reading.parameterName).filter(Boolean))];
            window.iotParameterUnits = Object.fromEntries(snapshot.devices.flatMap(device => Object.values(device.fields || {}).map(field => [field.name, field.unit || ""])));
            if (dashboardFieldSelect) {
                const selected = fields.includes(dashboardFieldSelect.value) ? dashboardFieldSelect.value : "";
                dashboardFieldSelect.innerHTML = `<option value="">All parameters</option>${fields.map(fieldName => `<option value="${escapeHtml(fieldName)}">${escapeHtml(fieldName)}</option>`).join("")}`;
                dashboardFieldSelect.value = selected;
            }
            renderParameterChart(currentReadings, dashboardFieldSelect?.value || "");
            updateLiveSummary(currentReadings, currentDevices);
            setTelemetryStatus(`Firestore live updates connected · ${currentDevices.length} devices`);
        }, error => setTelemetryStatus(`Firestore live update error: ${error.message}`));
        window.addEventListener("pagehide", unsubscribe, { once: true });
        setInterval(() => updateLiveDevicePresence(currentDevices), 15000);
    } catch (error) { setTelemetryStatus(`Live Firestore updates unavailable: ${error.message}`); }
});

let parameterChart;

function renderParameterChart(readings, selectedField) {
    const canvas = document.getElementById("sensorChart");
    if (!canvas || typeof Chart === "undefined") return;

    parameterChart?.destroy();
    const fields = selectedField ? [selectedField] : [...new Set(readings.map(reading => reading.parameterName).filter(Boolean))];
    const numericFields = fields.filter(name => readings.some(reading => reading.parameterName === name && (Number.isFinite(Number(reading.value)) || reading.state || /^(on|off)$/i.test(String(reading.rawValue ?? reading.value)))));
    const pointsByField = numericFields.map(name => {
        const points = readings
            .filter(reading => reading.parameterName === name && reading.timestamp && (Number.isFinite(Number(reading.value)) || reading.state || /^(on|off)$/i.test(String(reading.rawValue ?? reading.value))))
            .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
        return { name, points };
    }).filter(series => series.points.length);

    if (!pointsByField.length) {
        canvas.closest(".chart-container")?.querySelector(":scope > .chart-controls")?.remove();
        showChartEmptyState("chartEmpty", "sensorChart", false);
        return;
    }

    const container = canvas.closest(".chart-container");
    const series = pointsByField.length === 1 ? pointsByField[0] : {
        name: "All parameters",
        points: pointsByField.flatMap(item => item.points)
    };
    parameterChart = createTimeSeriesChart(canvas, series.points, { parameterName: series.name, fill: true, unit: window.iotParameterUnits?.[series.name], stepped: series.points.some(point => point.state) || /state|status|on.?off/i.test(series.name) });
    if (parameterChart) addChartControls(parameterChart, container);
    showChartEmptyState("chartEmpty", "sensorChart", true);
}

function updateLiveSummary(readings, devices) {
    const sorted = [...readings].sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
    const latest = sorted[sorted.length - 1];
    const selectedDevice = devices.find(device => device.id === document.getElementById("activeChannelSelect")?.value) || devices.find(device => sorted.some(reading => reading.deviceId === device.deviceId || reading.channelId === device.id));
    const stateDefinition = Object.values(selectedDevice?.fields || {}).find(field => field.type === "state");
    const stateParameter = stateDefinition?.name;
    const candidateState = [...sorted].reverse().find(reading => reading.state || (stateParameter && (reading.parameterName === stateParameter || reading.fieldName === stateDefinition?.fieldKey) && [0, 1].includes(Number(reading.value))));
    const latestState = candidateState ? { ...candidateState } : null;
    if (latestState && !latestState.state) latestState.state = Number(latestState.value) === 1 ? "ON" : "OFF";
    const latestNumeric = [...sorted].reverse().find(reading => reading.parameterName !== stateParameter && !reading.state && reading.value !== "" && Number.isFinite(Number(reading.value)));
    const gaugeReading = latestNumeric || latestState || latest;
    if (latest) {
        setText("currentLightState", latestState?.state || latest.parameterName || "Available");
        setText("lightStatus", latestState?.state || "Available");
        const unit = window.iotParameterUnits?.[gaugeReading.parameterName] || "";
        setText("lightValue", `${gaugeReading.parameterName}: ${gaugeReading.rawValue ?? gaugeReading.value}${unit ? ` ${unit}` : ""}`);
        setText("latestReading", `${latest.parameterName} at ${formatDateTime(latest.timestamp)}`);
        setText("lastUpdated", formatTime(latest.timestamp));
        setText("statusUpdated", formatTime(latest.timestamp));
        updateInsights(sorted.filter(reading => reading.parameterName === gaugeReading.parameterName));
    }
    const selectedId = document.getElementById("activeChannelSelect")?.value;
    const device = (selectedId && devices.find(item => item.id === selectedId || item.deviceId === selectedId)) || devices.find(item => sorted.some(reading => reading.deviceId === item.deviceId || reading.channelId === item.id)) || devices[0];
    const scopedDevices = selectedId ? devices.filter(item => item.id === selectedId || item.deviceId === selectedId) : devices;
    updateLiveDevicePresence(scopedDevices, device);
    updateDashboardGauge(gaugeReading, sorted);
}

function updateLiveDevicePresence(devices, selectedDevice) {
    const device = selectedDevice || devices.find(item => item.channelType === "channel") || devices[0];
    const lastSeen = device?.lastSeenAt?.toDate ? device.lastSeenAt.toDate() : new Date(device?.lastSeenAt || 0);
    const online = device && Number.isFinite(lastSeen.getTime()) && lastSeen.getTime() > 0 && Date.now() - lastSeen.getTime() <= Math.max(1, Number(device.offlineAfterMinutes) || 5) * 60000;
    setText("dashboardDeviceStatus", online ? "ONLINE" : "OFFLINE");
    setText("dashboardDeviceLastSeen", lastSeen.getTime() > 0 ? formatDateTime(lastSeen) : "No data received");
    setText("dashboardTopConnectionText", online ? `${device.name || device.deviceName || "Sensor"} ONLINE` : `${device?.name || device?.deviceName || "Sensor"} OFFLINE`);
}

function updateDashboardGauge(reading, readings) {
    const gauge = document.getElementById("dashboardValueGauge");
    if (!gauge) return;
    if (!reading || !Number.isFinite(Number(reading.value))) { gauge.value = 0; gauge.max = 1; return; }
    const values = readings.filter(item => item.parameterName === reading.parameterName && Number.isFinite(Number(item.value))).map(item => Number(item.value));
    const min = Math.min(0, ...values);
    const max = Math.max(min + 1, ...values);
    gauge.min = min; gauge.max = max; gauge.value = Number(reading.value);
    gauge.title = `${reading.parameterName}: ${reading.rawValue ?? reading.value}${window.iotParameterUnits?.[reading.parameterName] ? ` ${window.iotParameterUnits[reading.parameterName]}` : ""}`;
}

function updateInsights(dataArray) {
    const insight = generateIoTInsights(dataArray);
    const box = document.getElementById("insight-box");
    if (!box || !insight) return;
    box.dataset.tone = insight.tone;
    setText("insightTitle", insight.title);
    setText("insightMessage", insight.message);
}

function generateIoTInsights(dataArray) {
    const values = dataArray
        .filter(reading => reading.value !== null && String(reading.value).trim() !== "")
        .map(reading => Number(reading.value))
        .filter(Number.isFinite);
    if (!values.length) return null;

    const latest = values[values.length - 1];
    if (latest > 40) {
        return { tone: "danger", title: "Temperature hazard detected", message: `Latest reading is ${latest} °C, above the 40 °C safety threshold.` };
    }
    if (values.length > 1 && latest > values[values.length - 2]) {
        return { tone: "positive", title: "Positive upward trend", message: `Temperature is rising; the latest reading is ${latest} °C.` };
    }
    if (values.length > 1 && latest < values[values.length - 2]) {
        return { tone: "cooling", title: "Thermal decay detected", message: `Temperature is declining; the latest reading is ${latest} °C.` };
    }
    return { tone: "stable", title: "System operating steadily", message: `Temperature is stable at ${latest} °C.` };
}

function setTelemetryStatus(message) {
    const status = document.getElementById("telemetryStatus");
    if (!status) return;
    status.textContent = message;
    const badge = status.closest(".telemetry-monitor");
    if (!badge) return;
    badge.dataset.state = /error|not configured|missing/i.test(message)
        ? "error"
        : /waiting|connecting/i.test(message) ? "pending" : "connected";
}

function escapeHtml(value) {
    return String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}

function updateStat(card, value, message) {
    if (!card) return;
    card.querySelector(".stat-value").textContent = value;
    card.querySelector(".stat-change").textContent = message;
}

function setText(id, value) {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
}

function formatTime(value) {
    return new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", timeZone: localStorage.getItem("iot-insight-timezone") || "Asia/Kolkata" });
}

function formatDateTime(value) {
    return new Date(value).toLocaleString([], { dateStyle: "medium", timeStyle: "short", timeZone: localStorage.getItem("iot-insight-timezone") || "Asia/Kolkata" });
}
