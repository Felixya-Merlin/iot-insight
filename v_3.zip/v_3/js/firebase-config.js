/*
 * Public browser configuration is supplied by firebase-config.local.js.
 * It is separated from tracked app code for per-project deployment setup,
 * but values in a static web app are visible to every browser visitor.
 */
let firebaseConfig = {};
try {
    const localConfig = await import("./firebase-config.local.js");
    firebaseConfig = localConfig.firebaseConfig || {};
} catch (error) {
    console.warn("Firebase client configuration is missing. Copy js/firebase-config.example.js to js/firebase-config.local.js and fill in your Firebase Web App settings.");
}

export { firebaseConfig };
export const firebaseIsConfigured = Boolean(firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId && firebaseConfig.appId);
