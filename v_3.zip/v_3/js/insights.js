import { loadFirebaseData, showDataError } from "./firebase-data.js";
import { getReportItems, setReportItem } from "./firebase-service.js";
import { createTimeSeriesChart, addChartControls } from "./chart-factory.js";

document.addEventListener("DOMContentLoaded", async () => {
    const host = document.getElementById("insightsList");
    let data;
    try { data = await loadFirebaseData(); } catch (error) { showDataError(error); if (host) host.innerHTML = `<div class="empty-state error-state">${escapeHtml(error.message)}</div>`; return; }
    const readings = data.readings;
    window.iotParameterUnits = Object.fromEntries((data.parameters || []).map(item => [item.parameterName, item.unit || ""]));
    const fields = [...new Set(readings.map(reading => reading.parameterName))];
    const channel = data.devices.find(item => item.channelType === "channel" && readings.some(reading => reading.channelId === item.id || reading.deviceId === item.id)) || data.devices.find(item => item.channelType === "channel");
    const thresholds = channel?.alertSettings || {};
    const stateFieldName = Object.values(channel?.fields || {}).find(field => field.type === "state")?.name || fields.find(name => /state|status|on.?off/i.test(name));
    const stateParameterId = Object.values(channel?.fields || {}).find(field => field.type === "state")?.fieldKey;
    const insights = fields.map(field => {
        const values = readings.filter(reading => reading.parameterName === field).map(reading => Number(reading.value)).filter(Number.isFinite);
        if (!values.length) return { text: `${field} contains categorical observations across ${readings.filter(reading => reading.parameterName === field).length} records.` };
        const sorted = [...values].sort((a, b) => a - b); const minimum = sorted[0]; const maximum = sorted.at(-1); const average = values.reduce((sum, value) => sum + value, 0) / values.length;
        const median = sorted.length % 2 ? sorted[(sorted.length - 1) / 2] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2;
        const q1 = percentile(sorted, 0.25); const q3 = percentile(sorted, 0.75); const iqr = q3 - q1;
        const stdDev = Math.sqrt(values.reduce((sum, value) => sum + (value - average) ** 2, 0) / values.length);
        const numericItems = readings.filter(item => item.parameterName === field && Number.isFinite(Number(item.value))).sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
        const slope = regressionSlope(numericItems);
        const anomalies = values.filter(value => (stdDev && Math.abs((value - average) / stdDev) >= 3) || (iqr && (value < q1 - 1.5 * iqr || value > q3 + 1.5 * iqr))).length;
        const luxField = fields.find(name => /lux|light/i.test(name));
        const stateItems = readings.filter(item => item.state || (stateFieldName && (item.parameterName === stateFieldName || item.fieldName === stateParameterId))).map(item => ({ ...item, state: item.state || (Number(item.value) === 1 ? "ON" : Number(item.value) === 0 ? "OFF" : "") })).filter(item => item.state).sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
        const lightItemsOn = stateItems.flatMap((item, index) => {
            if (item.state !== "ON") return [];
            const nextState = stateItems.slice(index + 1).find(candidate => candidate.state !== "ON");
            const stop = nextState ? new Date(nextState.timestamp).getTime() : Date.now();
            return luxField ? readings.filter(reading => reading.parameterName === luxField && new Date(reading.timestamp).getTime() >= new Date(item.timestamp).getTime() && new Date(reading.timestamp).getTime() < stop) : [];
        });
        const switches = stateItems.slice(1).filter((item, index) => item.state !== stateItems[index].state).length;
        const onItems = stateItems.filter(item => item.state === "ON");
        const onHours = stateItems.reduce((sum, item, index) => {
            const next = stateItems[index + 1];
            if (item.state !== "ON") return sum;
            const stop = next ? new Date(next.timestamp) : new Date();
            return sum + Math.max(0, (stop - new Date(item.timestamp)) / 3600000);
        }, 0);
        const avgLuxOn = luxField && lightItemsOn.length ? lightItemsOn.filter(item => Number.isFinite(Number(item.value))).reduce((sum, item, _, list) => sum + Number(item.value) / list.length, 0) : null;
        const wattage = Number(thresholds.wattage ?? 40); const tariff = Number(thresholds.tariffPerKwh ?? 8); const energyKwh = onHours * wattage / 1000;
        const afterHoursPercent = stateItems.length ? stateItems.filter(item => item.state === "ON" && !isLabHour(item.timestamp, thresholds)).length / stateItems.length * 100 : 0;
        const degradation = estimateDegradation(stateFieldName ? lightItemsOn : numericItems);
        const trend = slope > 0.01 ? "increasing" : slope < -0.01 ? "decreasing" : "stable";
        const summary = `${field} averaged ${average.toFixed(2)} (median ${median.toFixed(2)}), with a ${trend} trend. ${anomalies} readings were statistical outliers.`;
        return { text: `${summary} Min ${minimum.toFixed(2)}, max ${maximum.toFixed(2)}, standard deviation ${stdDev.toFixed(2)}, slope ${slope.toFixed(4)} per hour. ${switches} ON/OFF switches, ${onHours.toFixed(1)} ON hours; ${avgLuxOn === null ? "average lux while ON unavailable" : `average ${luxField} while ON ${avgLuxOn.toFixed(1)}`}. Estimated energy ${energyKwh.toFixed(2)} kWh (INR ${(energyKwh * tariff).toFixed(2)}). ${afterHoursPercent.toFixed(1)}% ON outside lab hours. Estimated brightness change ${degradation === null ? "unavailable" : `${degradation.toFixed(1)}%`} across the period.` }
    });
    if (!insights.length) { host.innerHTML = `<div class="empty-state">Import a dataset to generate insights.</div>`; return; }
    const graphHost = document.getElementById("insightGraphs");
    if (graphHost && typeof Chart !== "undefined") fields.forEach((field, index) => {
        const items = readings.filter(reading => reading.parameterName === field && (Number.isFinite(Number(reading.value)) || reading.state || /^(on|off)$/i.test(String(reading.rawValue ?? reading.value))));
        if (!items.length) return;
        const card = document.createElement("section"); card.className = "chart-card"; card.innerHTML = `<h4>${field}</h4><canvas id="insight-chart-${index}"></canvas>`; graphHost.append(card);
        const chart = createTimeSeriesChart(document.getElementById(`insight-chart-${index}`), items, { parameterName: field, fill: true, stepped: items.some(item => item.state) || /state|status|on.?off/i.test(field) });
        addChartControls(chart, card);
    });
    const reportItems = await getReportItems().catch(() => []);
    host.innerHTML = insights.map((insight, index) => `<article class="insight-item" data-index="${index}"><p contenteditable="true">${escapeHtml(insight.text)}</p><div class="form-actions"><button type="button" data-flag>Flag</button><button type="button" data-report>${reportItems.some(item => item.text === insight.text) ? "Added" : "Add to report"}</button><button type="button" data-dismiss>Dismiss</button></div></article>`).join("");
    host.addEventListener("click", event => {
        const item = event.target.closest(".insight-item");
        if (!item) return;
        if (event.target.matches("[data-dismiss]")) item.remove();
        if (event.target.matches("[data-flag]")) item.classList.toggle("insight-flagged");
        if (event.target.matches("[data-report]")) { const text = item.querySelector("p").innerText; setReportItem(text, { channelId: channel?.id || "" }).then(() => { event.target.textContent = "Added"; }).catch(error => window.alert(error.message)); }
    });
});

function regressionSlope(items) {
    if (items.length < 2) return 0;
    const x0 = new Date(items[0].timestamp).getTime(); const xs = items.map(item => (new Date(item.timestamp).getTime() - x0) / 3600000); const ys = items.map(item => Number(item.value));
    const mx = xs.reduce((sum, value) => sum + value, 0) / xs.length; const my = ys.reduce((sum, value) => sum + value, 0) / ys.length;
    const denominator = xs.reduce((sum, value) => sum + (value - mx) ** 2, 0);
    return denominator ? xs.reduce((sum, value, index) => sum + (value - mx) * (ys[index] - my), 0) / denominator : 0;
}
function isLabHour(timestamp, config) {
    const date = new Date(timestamp); const parts = new Intl.DateTimeFormat("en-US", { timeZone: config.timeZone || "Asia/Kolkata", weekday: "short", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(date);
    const values = Object.fromEntries(parts.map(part => [part.type, part.value])); const minute = Number(values.hour) * 60 + Number(values.minute);
    return !["Sat", "Sun"].includes(values.weekday) && minute >= Number(config.labStartHour ?? 9) * 60 && minute < Number(config.labEndHour ?? 17) * 60;
}
function estimateDegradation(items) {
    if (items.length < 2) return null;
    const count = Math.max(1, Math.floor(items.length * 0.1)); const first = items.slice(0, count).reduce((sum, item) => sum + Number(item.value), 0) / count;
    const last = items.slice(-count).reduce((sum, item) => sum + Number(item.value), 0) / count;
    return first ? (first - last) / first * 100 : null;
}
function percentile(sorted, ratio) {
    if (!sorted.length) return 0;
    const index = (sorted.length - 1) * ratio; const lower = Math.floor(index); const upper = Math.ceil(index);
    return sorted[lower] + (sorted[upper] - sorted[lower]) * (index - lower);
}
function escapeHtml(value) { return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;"); }
