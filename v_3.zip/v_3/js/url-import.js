import { getCurrentUserIdToken, getDevices, isFirebaseReady, saveExternalChannelFeeds } from "./firebase-service.js";

const sourceUrlInput = document.getElementById("sourceApiUrl");
const targetChannelSelect = document.getElementById("sourceTargetChannel");
const previewButton = document.getElementById("previewApiUrl");
const saveButton = document.getElementById("saveUrlReadings");
const statusBox = document.getElementById("urlImportStatus");
const mappingHost = document.getElementById("urlFieldMapping");
const previewHost = document.getElementById("urlImportPreview");
const autoRefreshCheckbox = document.getElementById("autoRefreshUrl");
const refreshIntervalSelect = document.getElementById("autoRefreshInterval");

let selectedChannel = null;
let parsedFeed = null;
let normalizedFeeds = [];
let refreshTimer = null;
let inFlight = false;
let connected = false;
let savedSourceUrl = "";

function escapeHtml(value) {
    return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
}

function setStatus(message, type = "info") {
    statusBox.textContent = message;
    statusBox.className = `import-status show ${type}`;
}

function parseCsv(text) {
    const records = [];
    let row = [];
    let cell = "";
    let quoted = false;
    const input = text.replace(/^\uFEFF/, "");
    for (let index = 0; index < input.length; index += 1) {
        const character = input[index];
        if (character === '"' && quoted && input[index + 1] === '"') { cell += '"'; index += 1; }
        else if (character === '"') quoted = !quoted;
        else if (character === "," && !quoted) { row.push(cell.trim()); cell = ""; }
        else if ((character === "\n" || character === "\r") && !quoted) {
            if (character === "\r" && input[index + 1] === "\n") index += 1;
            row.push(cell.trim());
            if (row.some(value => value !== "")) records.push(row);
            row = []; cell = "";
        } else cell += character;
    }
    row.push(cell.trim());
    if (row.some(value => value !== "")) records.push(row);
    if (records.length < 2) throw new Error("CSV URL must contain a header and at least one data row.");
    const headers = records[0].map((value, index) => value || `column${index + 1}`);
    return { format: "CSV", columns: headers.map(key => ({ key, label: key })), rows: records.slice(1).map(values => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""]))) };
}

function parseFeedText(text, contentType = "") {
    const trimmed = text.trim();
    if (!trimmed) throw new Error("The source URL returned an empty response.");
    if (/^[\[{]/.test(trimmed) || /json/i.test(contentType)) {
        let payload;
        try { payload = JSON.parse(trimmed); } catch { throw new Error("The source response advertised JSON but was not valid JSON."); }
        if (payload && payload.channel && Array.isArray(payload.feeds)) {
            const columns = Object.keys(payload.channel).filter(key => /^field[1-8]$/.test(key) && payload.channel[key]).map(key => ({ key, label: payload.channel[key] }));
            if (!columns.length) throw new Error("ThingSpeak JSON has no configured field1..field8 names.");
            return { format: "ThingSpeak JSON", columns, rows: payload.feeds, metadata: payload.channel };
        }
        const rows = Array.isArray(payload) ? payload : [payload?.feeds, payload?.data, payload?.items].find(Array.isArray);
        if (!rows?.length || typeof rows[0] !== "object") throw new Error("Generic JSON must be an array of objects or contain a feeds, data, or items array.");
        const keys = [...new Set(rows.flatMap(row => Object.keys(row)))].filter(key => !/^(created_at|timestamp|time|date|entry_id)$/i.test(key));
        if (!keys.length) throw new Error("No data fields were found in the JSON rows.");
        return { format: "Generic JSON array", columns: keys.map(key => ({ key, label: key })), rows };
    }
    return parseCsv(trimmed);
}

function timestampFor(row) {
    const key = Object.keys(row).find(name => /^(created_at|timestamp|time|date)$/i.test(name));
    if (!key || row[key] === "" || row[key] === null || row[key] === undefined) return new Date().toISOString();
    const raw = row[key];
    const numeric = Number(raw);
    const date = Number.isFinite(numeric) ? new Date(Math.abs(numeric) < 1e12 ? numeric * 1000 : numeric) : new Date(raw);
    return Number.isFinite(date.getTime()) ? date.toISOString() : null;
}

function normalizeField(rawValue, field) {
    const text = String(rawValue ?? "").trim();
    if (!text) return { error: `${field.name}: empty value` };
    if (field.type === "state") {
        const value = text.toLowerCase();
        if (["on", "true", "1"].includes(value)) return { value: 1, state: "ON", rawValue: text };
        if (["off", "false", "0"].includes(value)) return { value: 0, state: "OFF", rawValue: text };
        return { error: `${field.name}: expected ON/OFF, true/false, or 1/0` };
    }
    const value = Number(text);
    if (!Number.isFinite(value)) return { error: `${field.name}: not numeric` };
    if (field.minValue !== undefined && value < Number(field.minValue)) return { error: `${field.name}: below minimum ${field.minValue}` };
    if (field.minValue === undefined && /lux/i.test(field.unit || "") && value < 0) return { error: `${field.name}: lux cannot be negative` };
    return { value, state: "", rawValue: text };
}

function sourceKey(row, index) {
    const entryKey = Object.keys(row).find(key => /^entry_id$/i.test(key));
    if (entryKey && row[entryKey] !== "" && row[entryKey] !== null) return String(row[entryKey]);
    return JSON.stringify(row);
}

function targetFields() { return Object.values(selectedChannel?.fields || {}); }

function inferredSource(targetField) {
    if (!parsedFeed) return "";
    const normalize = value => String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    return parsedFeed.columns.find(column => column.key === targetField.fieldKey)?.key ||
        parsedFeed.columns.find(column => normalize(column.label) === normalize(targetField.name))?.key ||
        parsedFeed.columns.find(column => /^field\d+$/.test(column.key) && column.key === targetField.fieldKey)?.key || "";
}

function renderMappings() {
    if (!parsedFeed || !selectedChannel) { mappingHost.replaceChildren(); return; }
    const previous = Object.fromEntries([...mappingHost.querySelectorAll("[data-target-field]")].map(control => [control.dataset.targetField, control.value]));
    mappingHost.innerHTML = targetFields().map(field => {
        const selectedSource = previous[field.fieldKey] ?? inferredSource(field);
        const options = [`<option value="">Do not map</option>`, ...parsedFeed.columns.map(column => `<option value="${escapeHtml(column.key)}" ${selectedSource === column.key ? "selected" : ""}>${escapeHtml(column.label)} (${escapeHtml(column.key)})</option>`)];
        return `<div class="form-group"><label for="url-map-${escapeHtml(field.fieldKey)}">${escapeHtml(field.name)}${field.unit ? ` (${escapeHtml(field.unit)})` : ""}</label><select id="url-map-${escapeHtml(field.fieldKey)}" data-target-field="${escapeHtml(field.fieldKey)}">${options.join("")}</select></div>`;
    }).join("");
    mappingHost.querySelectorAll("select").forEach(select => select.addEventListener("change", renderPreview));
    renderPreview();
}

function renderPreview() {
    if (!parsedFeed || !selectedChannel) return;
    const errors = [];
    normalizedFeeds = parsedFeed.rows.flatMap((row, index) => {
        const timestamp = timestampFor(row);
        if (!timestamp) { errors.push(`Row ${index + 1}: invalid timestamp`); return []; }
        const values = {};
        for (const control of mappingHost.querySelectorAll("[data-target-field]")) {
            const source = control.value;
            if (!source) continue;
            const targetKey = control.dataset.targetField;
            const field = selectedChannel.fields[targetKey];
            if (row[source] === undefined || row[source] === null || row[source] === "") continue;
            const result = normalizeField(row[source], field);
            if (result.error) errors.push(`Row ${index + 1}: ${result.error}`);
            else values[targetKey] = result;
        }
        if (!Object.keys(values).length) return [];
        return [{ timestamp, sourceEntryId: sourceKey(row, index), values }];
    });
    normalizedFeeds = [...new Map(normalizedFeeds.map(feed => [feed.sourceEntryId, feed])).values()];
    const previewRows = normalizedFeeds.slice(0, 20);
    const columns = targetFields().filter(field => [...mappingHost.querySelectorAll("[data-target-field]")].some(control => control.dataset.targetField === field.fieldKey && control.value));
    previewHost.innerHTML = `<table class="preview-table"><thead><tr><th>Created at</th><th>Entry</th>${columns.map(field => `<th>${escapeHtml(field.name)}</th>`).join("")}</tr></thead><tbody>${previewRows.map(feed => `<tr><td>${escapeHtml(feed.timestamp)}</td><td>${escapeHtml(feed.sourceEntryId)}</td>${columns.map(field => { const value = feed.values[field.fieldKey]; return `<td>${value ? escapeHtml(value.rawValue) : "—"}</td>`; }).join("")}</tr>`).join("")}</tbody></table><p class="muted" style="margin-top:10px">Detected ${escapeHtml(parsedFeed.format)} · previewing ${previewRows.length} of ${normalizedFeeds.length} valid feed rows${errors.length ? ` · ${errors.length} invalid field values/rows will be skipped` : ""}.</p>`;
    saveButton.disabled = normalizedFeeds.length === 0;
    saveButton.textContent = connected ? "Save current preview" : "Save to channel";
    if (errors.length) setStatus(`${errors.length} invalid value(s) or timestamp(s) were flagged and will not be saved.`, "error");
}

async function fetchSource(url) {
    let response;
    try { response = await fetch(url, { headers: { Accept: "application/json, text/csv, text/plain" } }); }
    catch (error) {
        const idToken = await getCurrentUserIdToken();
        const proxy = await fetch(`${window.location.origin}/api/import-proxy`, {
            method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` }, body: JSON.stringify({ url })
        });
        const result = await proxy.json().catch(() => ({}));
        if (!proxy.ok) throw new Error(result.error?.message || `URL proxy failed (${proxy.status}).`);
        return { text: result.text, contentType: result.contentType || "" };
    }
    if (!response.ok) throw new Error(`Source URL returned HTTP ${response.status}.`);
    return { text: await response.text(), contentType: response.headers.get("content-type") || "" };
}

function safeSourceUrl(value) {
    const url = new URL(value);
    for (const key of [...url.searchParams.keys()]) if (/api.?key|token|password|secret|auth/i.test(key)) url.searchParams.delete(key);
    return url.toString();
}

async function refreshPreview(isAutomatic = false) {
    if (inFlight) return;
    const rawUrl = sourceUrlInput.value.trim();
    if (!rawUrl) { setStatus("Paste a feed URL first.", "error"); return; }
    if (!selectedChannel) { setStatus("Create or select a channel before connecting a URL.", "error"); return; }
    inFlight = true;
    if (!isAutomatic) { previewButton.disabled = true; saveButton.disabled = true; }
    try {
        const result = await fetchSource(rawUrl);
        parsedFeed = parseFeedText(result.text, result.contentType);
        savedSourceUrl = safeSourceUrl(rawUrl);
        if (!isAutomatic || !mappingHost.querySelector("[data-target-field]")) renderMappings();
        else renderPreview();
        if (!isAutomatic) setStatus(`${parsedFeed.rows.length} source rows loaded. Review the mapping and preview, then save.`, "success");
        return true;
    } catch (error) {
        console.error("URL import failed", error);
        if (!isAutomatic) setStatus(error.message || "Could not read this URL.", "error");
        else setStatus(`Auto-refresh failed: ${error.message}`, "error");
        return false;
    } finally {
        inFlight = false;
        previewButton.disabled = false;
        if (!normalizedFeeds.length) saveButton.disabled = true;
    }
}

function stopAutoRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = null;
}

function startAutoRefresh() {
    stopAutoRefresh();
    if (!connected || !autoRefreshCheckbox.checked) return;
    const seconds = Number(refreshIntervalSelect.value) === 30 ? 30 : 15;
    refreshTimer = setInterval(async () => {
        if (!await refreshPreview(true) || !normalizedFeeds.length) return;
        const freshFeeds = normalizedFeeds.filter(feed => !savedSourceEntries.has(feed.sourceEntryId));
        if (!freshFeeds.length) return;
        try {
            const saved = await saveExternalChannelFeeds(selectedChannel.id, freshFeeds, savedSourceUrl);
            freshFeeds.forEach(feed => savedSourceEntries.add(feed.sourceEntryId));
            setStatus(`Auto-refresh connected · ${saved} new feed row(s) saved.`, "success");
        } catch (error) { setStatus(`Auto-import failed: ${error.message}`, "error"); }
    }, seconds * 1000);
}

const savedSourceEntries = new Set();

targetChannelSelect.addEventListener("change", () => {
    stopAutoRefresh();
    connected = false;
    savedSourceEntries.clear();
    selectedChannel = window.urlImportChannels?.find(channel => channel.id === targetChannelSelect.value) || null;
    if (parsedFeed) renderMappings();
});
sourceUrlInput.addEventListener("change", () => {
    stopAutoRefresh();
    connected = false;
    parsedFeed = null;
    normalizedFeeds = [];
    savedSourceEntries.clear();
    saveButton.disabled = true;
});
previewButton.addEventListener("click", () => refreshPreview(false));
saveButton.addEventListener("click", async () => {
    if (!isFirebaseReady() || !selectedChannel || !normalizedFeeds.length) return;
    saveButton.disabled = true;
    try {
        const saved = await saveExternalChannelFeeds(selectedChannel.id, normalizedFeeds, savedSourceUrl);
        normalizedFeeds.forEach(feed => savedSourceEntries.add(feed.sourceEntryId));
        connected = true;
        setStatus(`${saved} new feed row(s) saved to ${selectedChannel.name || selectedChannel.deviceName}.`, "success");
        startAutoRefresh();
    } catch (error) { setStatus(error.message, "error"); }
    finally { saveButton.disabled = false; }
});
autoRefreshCheckbox.addEventListener("change", startAutoRefresh);
refreshIntervalSelect.addEventListener("change", startAutoRefresh);
window.addEventListener("pagehide", stopAutoRefresh, { once: true });

document.addEventListener("DOMContentLoaded", async () => {
    try {
        const channels = (await getDevices()).filter(channel => channel.channelType === "channel" && channel.ownerUid);
        window.urlImportChannels = channels;
        targetChannelSelect.innerHTML = channels.length
            ? channels.map(channel => `<option value="${escapeHtml(channel.id)}">${escapeHtml(channel.name || channel.deviceName)}${channel.location ? ` · ${escapeHtml(channel.location)}` : ""}</option>`).join("")
            : `<option value="">No channels yet</option>`;
        selectedChannel = channels[0] || null;
        if (!channels.length) setStatus("Create a channel in Channels first, then return here to map and import feed fields.", "info");
    } catch (error) { setStatus(error.message, "error"); }
});
