import {
    getAllReadings,
    getDevices,
    getParameters,
    isFirebaseReady
} from "./firebase-service.js";
import { loadThingSpeakData } from "./thingspeak-service.js";

export async function loadFirebaseData() {
    if (!isFirebaseReady()) throw new Error("Firebase is not configured. Add the Firebase Web App settings first.");
    const [readings, devices, parameters] = await Promise.all([
        getAllReadings(),
        getDevices(),
        getParameters()
    ]);
    if (readings.length || localStorage.getItem("iot-insight-active-import")) return { readings, devices, parameters, source: "Firebase" };
    try { return await loadThingSpeakData(); } catch (error) { console.warn("ThingSpeak fallback unavailable", error); return { readings, devices, parameters, source: "Firebase" }; }
}

export function showDataError(error) {
    console.error(error);
    let message = document.querySelector("[data-data-message]");
    if (!message) {
        message = document.createElement("div");
        message.dataset.dataMessage = "";
        message.className = "page-state-error";
        message.setAttribute("role", "alert");
        (document.querySelector(".page-content") || document.querySelector("main") || document.body).prepend(message);
    }
    message.textContent = error?.message || "Data could not be loaded. Check your connection and try again.";
    message.classList.remove("hidden");
}
