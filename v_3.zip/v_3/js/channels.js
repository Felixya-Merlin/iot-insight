import { deleteChannel, getDevices, regenerateChannelKey, saveChannel } from "./firebase-service.js";

const form = document.getElementById("channelForm");
const fieldsHost = document.getElementById("channelFields");
const list = document.getElementById("channelList");
const message = document.getElementById("channelMessage");

function escapeHtml(value) { return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;"); }
function addField(field = {}) {
    if (fieldsHost.children.length >= 8) return;
    const usedKeys = new Set([...fieldsHost.children].map(row => row.dataset.fieldKey));
    const fieldKey = field.fieldKey || Array.from({ length: 8 }, (_, index) => `field${index + 1}`).find(key => !usedKeys.has(key));
    const row = document.createElement("div");
    row.className = "channel-field-row";
    row.dataset.fieldKey = fieldKey;
    row.innerHTML = `<input aria-label="Field name" placeholder="Field ${fieldsHost.children.length + 1}" maxlength="60" value="${escapeHtml(field.name || "")}" required><input aria-label="Unit" placeholder="Unit" maxlength="20" value="${escapeHtml(field.unit || "")}"><select aria-label="Value type"><option value="numeric" ${field.type !== "state" ? "selected" : ""}>Numeric</option><option value="state" ${field.type === "state" ? "selected" : ""}>ON/OFF state</option></select><button type="button" class="btn btn-secondary" data-remove-field aria-label="Remove field">Remove</button>`;
    row.querySelector("[data-remove-field]").addEventListener("click", () => { row.remove(); updateFieldControls(); });
    fieldsHost.append(row);
    updateFieldControls();
}
function updateFieldControls() { document.getElementById("addChannelField").disabled = fieldsHost.children.length >= 8; }
function collectFields() {
    return [...fieldsHost.children].map(row => ({ fieldKey: row.dataset.fieldKey, name: row.children[0].value.trim(), unit: row.children[1].value.trim(), type: row.children[2].value }));
}
function showMessage(text, isError = false) { message.textContent = text; message.classList.remove("hidden"); message.classList.toggle("error", isError); }

async function renderChannels() {
    const channels = (await getDevices()).filter(item => item.channelType === "channel");
    list.innerHTML = channels.length ? channels.map(channel => `<article class="channel-card" data-channel="${escapeHtml(channel.id)}">
        <h3>${escapeHtml(channel.name || channel.deviceName)} ${channel.isSimulated ? '<span class="simulated-badge">SIMULATED</span>' : ""}</h3><p>${escapeHtml(channel.location || "Location not set")} · ${channel.status === "online" ? "ONLINE" : "OFFLINE"} · ${channel.isSimulated ? "Simulator" : "Device"}${channel.isPublic ? " · Public reads" : " · Private"}</p>
        <p>Fields: ${escapeHtml(Object.values(channel.fields || {}).map(field => `${field.name} (${field.fieldKey})`).join(", "))}</p>
        <details class="channel-alert-settings"><summary>Alert thresholds and lab hours</summary><div class="form-grid">
            <label class="form-group">Dim threshold (lux)<input type="number" min="0" data-alert-setting="dimThresholdLux" value="${Number(channel.alertSettings?.dimThresholdLux ?? 200)}"></label>
            <label class="form-group">Flicker variance (lux²)<input type="number" min="1" data-alert-setting="flickerVarianceThreshold" value="${Number(channel.alertSettings?.flickerVarianceThreshold ?? 10000)}"></label>
            <label class="form-group">Lab starts (hour, 0-23)<input type="number" min="0" max="23" data-alert-setting="labStartHour" value="${Number(channel.alertSettings?.labStartHour ?? 9)}"></label>
            <label class="form-group">Lab ends (hour, 0-24)<input type="number" min="1" max="24" data-alert-setting="labEndHour" value="${Number(channel.alertSettings?.labEndHour ?? 17)}"></label>
            <label class="form-group">Tube wattage<input type="number" min="0" step="0.1" data-alert-setting="wattage" value="${Number(channel.alertSettings?.wattage ?? 40)}"></label>
            <label class="form-group">Tariff per kWh<input type="number" min="0" step="0.01" data-alert-setting="tariffPerKwh" value="${Number(channel.alertSettings?.tariffPerKwh ?? 8)}"></label>
            <label class="form-group">Timezone<input data-alert-setting="timeZone" value="${escapeHtml(channel.alertSettings?.timeZone || "Asia/Kolkata")}"></label>
            <label class="form-group"><span>Expect ON during lab</span><input type="checkbox" data-alert-setting="expectedOnDuringLab" ${channel.alertSettings?.expectedOnDuringLab !== false ? "checked" : ""}></label>
            <label class="form-group"><span>Expect OFF outside lab</span><input type="checkbox" data-alert-setting="expectedOffOutsideLab" ${channel.alertSettings?.expectedOffOutsideLab !== false ? "checked" : ""}></label>
        </div><div style="margin:12px 0"><label><input type="checkbox" data-alert-setting="enabled" ${channel.alertSettings?.enabled !== false ? "checked" : ""}> Enable alerts</label> <label><input type="checkbox" data-alert-setting="expectedStateAlerts" ${channel.alertSettings?.expectedStateAlerts !== false ? "checked" : ""}> Enable lab-hours ON/OFF alerts</label></div><button type="button" class="btn btn-secondary" data-save-alert-settings>Save alert settings</button></details>
        <p class="muted">Last seen: ${channel.lastSeenAt?.toDate ? new Date(channel.lastSeenAt.toDate()).toLocaleString("en-IN", { timeZone: localStorage.getItem("iot-insight-timezone") || "Asia/Kolkata" }) : "No data received yet"}</p>
        <div class="key-row"><strong>Write key</strong><input type="password" readonly value="${escapeHtml(channel.writeApiKey)}" aria-label="Write API key"><button type="button" data-show-key>Show</button><button type="button" data-copy-key="writeApiKey">Copy</button><button type="button" data-regenerate="writeApiKey">Regenerate</button></div>
        <div class="key-row"><strong>Read key</strong><input type="password" readonly value="${escapeHtml(channel.readApiKey)}" aria-label="Read API key"><button type="button" data-show-key>Show</button><button type="button" data-copy-key="readApiKey">Copy</button><button type="button" data-regenerate="readApiKey">Regenerate</button></div>
        <div class="form-actions"><a class="btn btn-primary" href="device-setup.html?id=${encodeURIComponent(channel.id)}">Device setup</a><button type="button" class="btn btn-secondary" data-edit> Edit</button><button type="button" class="btn btn-secondary" data-delete>Delete</button></div>
    </article>`).join("") : `<div class="empty-state">No channels yet. Create a channel above.</div>`;
    list.querySelectorAll("[data-show-key]").forEach(button => button.addEventListener("click", () => {
        const input = button.parentElement.querySelector("input");
        input.type = input.type === "password" ? "text" : "password";
        button.textContent = input.type === "password" ? "Show" : "Hide";
    }));
    list.querySelectorAll("[data-copy-key]").forEach(button => button.addEventListener("click", async () => {
        await navigator.clipboard.writeText(button.parentElement.querySelector("input").value);
        button.textContent = "Copied";
        setTimeout(() => { button.textContent = "Copy"; }, 1200);
    }));
    list.querySelectorAll("[data-regenerate]").forEach(button => button.addEventListener("click", async () => {
        const keyName = button.dataset.regenerate;
        if (!window.confirm(`Regenerate this ${keyName === "writeApiKey" ? "write" : "read"} key? Devices using the current key will need updating.`)) return;
        try { await regenerateChannelKey(button.closest("[data-channel]").dataset.channel, keyName); await renderChannels(); showMessage("Key regenerated."); }
        catch (error) { showMessage(error.message, true); }
    }));
    list.querySelectorAll("[data-edit]").forEach(button => button.addEventListener("click", () => {
        const channel = channels.find(item => item.id === button.closest("[data-channel]").dataset.channel);
        document.getElementById("channelEditId").value = channel.id;
        document.getElementById("channelName").value = channel.name || channel.deviceName || "";
        document.getElementById("channelLocation").value = channel.location || "";
        document.getElementById("channelRateLimit").value = channel.rateLimitSeconds || 15;
        document.getElementById("channelOfflineAfter").value = channel.offlineAfterMinutes || 5;
        document.getElementById("channelPublic").checked = Boolean(channel.isPublic);
        document.getElementById("channelSimulated").checked = Boolean(channel.isSimulated);
        fieldsHost.replaceChildren();
        Object.values(channel.fields || {}).forEach(addField);
        document.getElementById("channelFormTitle").textContent = "Edit channel";
        document.getElementById("cancelChannelEdit").hidden = false;
        form.scrollIntoView({ behavior: "smooth" });
    }));
    list.querySelectorAll("[data-save-alert-settings]").forEach(button => button.addEventListener("click", async () => {
        const card = button.closest("[data-channel]");
        const channel = channels.find(item => item.id === card.dataset.channel);
        const settings = {};
        card.querySelectorAll("[data-alert-setting]").forEach(input => { settings[input.dataset.alertSetting] = input.type === "checkbox" ? input.checked : (input.type === "number" ? Number(input.value) : input.value.trim()); });
        try { await saveChannel({ ...channel, name: channel.name || channel.deviceName || "Channel", location: channel.location || "", fields: Object.values(channel.fields || {}), alertSettings: settings }); await renderChannels(); showMessage("Alert and energy settings saved."); }
        catch (error) { showMessage(error.message, true); }
    }));
    list.querySelectorAll("[data-delete]").forEach(button => button.addEventListener("click", async () => {
        const channelId = button.closest("[data-channel]").dataset.channel;
        if (!window.confirm("Delete this channel, field definitions, and its readings?")) return;
        try { await deleteChannel(channelId); await renderChannels(); showMessage("Channel and its readings deleted."); }
        catch (error) { showMessage(error.message, true); }
    }));
}

document.getElementById("addChannelField").addEventListener("click", () => addField());
document.getElementById("cancelChannelEdit").addEventListener("click", () => resetForm());
form.addEventListener("submit", async event => {
    event.preventDefault();
    if (!fieldsHost.children.length || collectFields().some(field => !field.name)) return showMessage("Add at least one field and give each a name.", true);
    try {
        await saveChannel({ id: document.getElementById("channelEditId").value || "", name: document.getElementById("channelName").value.trim(), location: document.getElementById("channelLocation").value.trim(), isPublic: document.getElementById("channelPublic").checked, isSimulated: document.getElementById("channelSimulated").checked, rateLimitSeconds: document.getElementById("channelRateLimit").value, offlineAfterMinutes: document.getElementById("channelOfflineAfter").value, fields: collectFields() });
        resetForm(); await renderChannels(); showMessage("Channel saved.");
    } catch (error) { showMessage(error.message, true); }
});
function resetForm() { form.reset(); document.getElementById("channelEditId").value = ""; fieldsHost.replaceChildren(); addField({ name: "Light intensity", unit: "lux", type: "numeric" }); addField({ name: "Tube state", type: "state" }); document.getElementById("channelFormTitle").textContent = "Create a channel"; document.getElementById("cancelChannelEdit").hidden = true; }

document.addEventListener("DOMContentLoaded", async () => { resetForm(); try { await renderChannels(); } catch (error) { showMessage(error.message, true); } });
