import { createTimeSeriesChart, addChartControls } from "./chart-factory.js";

const params = new URLSearchParams(window.location.search);
const channelId = (params.get("channel") || "").trim();
const fieldNumber = Number(params.get("field"));
const status = document.getElementById("embedStatus");
const title = document.getElementById("embedTitle");
const errorBox = document.getElementById("embedError");

function showError(message) {
    status.textContent = "Unable to display chart";
    errorBox.textContent = message;
    errorBox.hidden = false;
}

async function loadChart() {
    if (!channelId || !Number.isInteger(fieldNumber) || fieldNumber < 1 || fieldNumber > 8) {
        showError("Use /embed.html?channel=PUBLIC_CHANNEL_ID&field=1 with a field number from 1 to 8.");
        return;
    }
    const baseUrl = `/api/channels/${encodeURIComponent(channelId)}`;
    try {
        const [feedResponse, fieldResponse] = await Promise.all([
            fetch(`${baseUrl}/feeds.json?results=8000`),
            fetch(`${baseUrl}/fields/${fieldNumber}.json`)
        ]);
        if (feedResponse.status === 401 || fieldResponse.status === 401) throw new Error("This channel is private. Embeds are available for public channels.");
        if (!feedResponse.ok || !fieldResponse.ok) throw new Error(`Channel API returned HTTP ${!feedResponse.ok ? feedResponse.status : fieldResponse.status}.`);
        const payload = await feedResponse.json();
        const fieldPayload = await fieldResponse.json();
        const fieldKey = `field${fieldNumber}`;
        const fieldName = payload.channel?.[fieldKey] || fieldPayload.field?.field || fieldKey;
        const fieldType = fieldPayload.field?.type || "numeric";
        const unit = fieldPayload.field?.unit || "";
        window.iotParameterUnits = { [fieldName]: unit };
        const readings = (payload.feeds || []).flatMap(feed => {
            const rawValue = feed[fieldKey];
            if (rawValue === null || rawValue === undefined || rawValue === "") return [];
            const isOn = ["1", "on", "true"].includes(String(rawValue).toLowerCase());
            const isOff = ["0", "off", "false"].includes(String(rawValue).toLowerCase());
            if (fieldType === "state" && !isOn && !isOff) return [];
            return [{
                timestamp: feed.created_at,
                entryId: feed.entry_id,
                parameterName: fieldName,
                value: fieldType === "state" ? (isOn ? 1 : 0) : rawValue,
                rawValue: fieldType === "state" ? (isOn ? "ON" : "OFF") : rawValue,
                state: fieldType === "state" ? (isOn ? "ON" : "OFF") : ""
            }];
        });
        title.textContent = `${payload.channel?.name || `Channel ${channelId}`} · ${fieldName}`;
        if (!readings.length) { status.textContent = "No readings yet"; return; }
        const chart = createTimeSeriesChart(document.getElementById("embedChart"), readings, {
            parameterName: fieldName, unit, stepped: fieldType === "state", fill: fieldType !== "state", maxTicksLimit: 7
        });
        addChartControls(chart, document.querySelector(".chart-container"));
        status.textContent = `${readings.length} public readings`;
    } catch (error) {
        showError(error.message || "The public feed could not be loaded.");
    }
}

loadChart();
