import { getUserAlerts, subscribeToUserAlerts, updateAlertStatus } from "./firebase-service.js";

const filters = {
    startDate: document.getElementById("alertStartDate"), endDate: document.getElementById("alertEndDate"),
    severity: document.getElementById("alertSeverity"), type: document.getElementById("alertType"),
    status: document.getElementById("alertStatus"), source: document.getElementById("alertSource")
};
let alerts = [];
let quickFilter = "all";
const safe = value => String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");

function populate(select, values, label) {
    const selected = select.value;
    select.innerHTML = `<option value="all">All ${label}</option>${[...new Set(values.filter(Boolean))].sort().map(value => `<option value="${safe(value)}">${safe(value)}</option>`).join("")}`;
    if ([...select.options].some(option => option.value === selected)) select.value = selected;
}
function visible(alert) {
    const time = new Date(alert.timestamp || 0).getTime();
    const start = filters.startDate.value ? new Date(`${filters.startDate.value}T00:00:00`).getTime() : -Infinity;
    const end = filters.endDate.value ? new Date(`${filters.endDate.value}T23:59:59.999`).getTime() : Infinity;
    return time >= start && time <= end && (quickFilter === "all" || alert.severity === quickFilter || alert.status === quickFilter)
        && (filters.severity.value === "all" || alert.severity === filters.severity.value)
        && (filters.type.value === "all" || alert.type === filters.type.value)
        && (filters.status.value === "all" || alert.status === filters.status.value)
        && (filters.source.value === "all" || alert.source === filters.source.value);
}
function render() {
    const rows = alerts.filter(visible);
    const summary = document.querySelectorAll(".summary-card strong");
    if (summary[0]) summary[0].textContent = rows.length;
    if (summary[1]) summary[1].textContent = rows.filter(alert => alert.severity === "critical").length;
    if (summary[2]) summary[2].textContent = rows.filter(alert => alert.severity === "warning").length;
    if (summary[3]) summary[3].textContent = rows.filter(alert => alert.status === "resolved").length;
    document.querySelectorAll(".filter-tab").forEach(button => button.classList.toggle("active", button.dataset.filter === quickFilter));
    document.getElementById("alertsTableBody").innerHTML = rows.map(alert => `<tr>
        <td>${safe(new Date(alert.timestamp || 0).toLocaleString("en-IN", { timeZone: localStorage.getItem("iot-insight-timezone") || "Asia/Kolkata" }))}</td>
        <td>${safe(alert.deviceName || alert.deviceId || alert.channelId)}</td><td>${safe(alert.parameterName)}</td>
        <td>${safe(alert.type)}</td><td>${safe(alert.value)}</td><td>${safe(alert.threshold)}</td>
        <td>${safe(alert.severity)}</td><td>${safe(alert.status)}</td><td>${safe(alert.source)}</td>
        <td>${alert.status === "open" ? `<button type="button" data-alert-action="acknowledged" data-alert-id="${safe(alert.id)}">Acknowledge</button>` : ""}${alert.status !== "resolved" ? `<button type="button" data-alert-action="resolved" data-alert-id="${safe(alert.id)}">Resolve</button>` : ""}</td>
    </tr>`).join("");
    document.getElementById("alertsEmptyState").style.display = rows.length ? "none" : "block";
}
async function load() {
    try {
        alerts = await getUserAlerts();
        populate(filters.type, alerts.map(alert => alert.type), "types");
        populate(filters.source, alerts.map(alert => alert.source), "sources");
        render();
    } catch (error) {
        document.getElementById("alertsEmptyState").style.display = "block";
        document.getElementById("alertsEmptyState").querySelector("p").textContent = error.message;
    }
}
document.addEventListener("DOMContentLoaded", () => {
    Object.values(filters).forEach(input => input.addEventListener("change", render));
    document.querySelectorAll(".filter-tab").forEach(button => button.addEventListener("click", () => {
        quickFilter = button.dataset.filter;
        document.querySelectorAll(".filter-tab").forEach(item => item.classList.toggle("active", item === button));
        render();
    }));
    document.getElementById("resetAlertFilters").addEventListener("click", () => {
        Object.values(filters).forEach(input => { input.value = input.type === "date" ? "" : "all"; });
        quickFilter = "all"; render();
    });
    document.getElementById("alertsTableBody").addEventListener("click", async event => {
        const button = event.target.closest("[data-alert-action]");
        if (!button) return;
        button.disabled = true;
        try { await updateAlertStatus(button.dataset.alertId, button.dataset.alertAction); await load(); }
        catch (error) { button.disabled = false; window.alert(error.message); }
    });
    load().then(async () => {
        try {
            const unsubscribe = await subscribeToUserAlerts(nextAlerts => { alerts = nextAlerts; populate(filters.type, alerts.map(alert => alert.type), "types"); populate(filters.source, alerts.map(alert => alert.source), "sources"); render(); }, error => console.error("Alert updates failed", error));
            window.addEventListener("pagehide", unsubscribe, { once: true });
        } catch (error) { console.error("Alert updates could not start", error); }
    });
});
