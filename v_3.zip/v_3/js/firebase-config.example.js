// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDYa-T-OJzZYC5kcIge3YaP2tC1BCh1LVs",
  authDomain: "iot-insight.firebaseapp.com",
  projectId: "iot-insight",
  storageBucket: "iot-insight.firebasestorage.app",
  messagingSenderId: "1090600142616",
  appId: "1:1090600142616:web:3ceec3c1a382793a69406d",
  measurementId: "G-GHYB7G0SZN"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);