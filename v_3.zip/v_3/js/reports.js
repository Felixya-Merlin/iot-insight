import { loadFirebaseData, showDataError } from "./firebase-data.js";
import { createTimeSeriesChart, addChartControls } from "./chart-factory.js";
import { getCurrentUserId, getReportItems, getUserAlerts } from "./firebase-service.js";

document.addEventListener("DOMContentLoaded", async () => {
    const preview = document.getElementById("reportPreview");
    const message = document.getElementById("reportMessage");
    const form = document.getElementById("reportForm");
    let reportCharts = [];
    try {
        const [data, savedReportItems, allAlerts, userId] = await Promise.all([
            loadFirebaseData(), getReportItems().catch(() => []), getUserAlerts().catch(() => []), getCurrentUserId()
        ]);
        const { readings: allReadings = [], devices = [], parameters = [] } = data;
        const channels = devices.filter(item => item.channelType === "channel");
        const deviceSelect = document.getElementById("reportDevice");
        const parameterSelect = document.getElementById("reportParameter");
        const graphSelection = document.getElementById("reportGraphs");
        const channelById = id => channels.find(channel => channel.id === id || channel.deviceId === id);
        const channelForReading = reading => channelById(reading.channelId || reading.deviceId);
        const matchedChannels = channels.filter(channel => allReadings.some(reading => channelForReading(reading)?.id === channel.id));
        const options = matchedChannels.length ? matchedChannels : channels;
        deviceSelect.innerHTML = `<option value="">${options.length ? "Select channel" : "No channels available"}</option>${options.map(channel => `<option value="${escapeHtml(channel.id)}">${escapeHtml(channel.name || channel.deviceName || channel.id)}${channel.isSimulated ? " (SIMULATED)" : ""}</option>`).join("")}`;
        if (options.length) deviceSelect.value = options[0].id;
        const graphChecks = new Map();
        const user = await currentUserLabel(userId);
        const fieldDefinitions = channel => Object.values(channel?.fields || {});
        const channelReadings = channel => allReadings.filter(reading => channelForReading(reading)?.id === channel?.id);
        const timezone = () => localStorage.getItem("iot-insight-timezone") || "Asia/Kolkata";
        const formatDate = value => value ? new Date(value).toLocaleString("en-IN", { timeZone: timezone() }) : "Not set";

        function readingsInRange(channel) {
            const start = document.getElementById("startDate").value;
            const end = document.getElementById("endDate").value;
            const startTime = start ? new Date(`${start}T00:00:00`).getTime() : -Infinity;
            const endTime = end ? new Date(`${end}T23:59:59.999`).getTime() : Infinity;
            return channelReadings(channel).filter(reading => {
                const time = new Date(reading.timestamp).getTime();
                return time >= startTime && time <= endTime && (!parameterSelect.value || reading.parameterName === parameterSelect.value);
            }).sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
        }

        function definitionsFor(channel) {
            const definitions = fieldDefinitions(channel);
            const names = [...new Set([...definitions.map(field => field.name), ...channelReadings(channel).map(reading => reading.parameterName)].filter(Boolean))];
            return names.map(name => definitions.find(field => field.name === name) || parameters.find(item => item.parameterName === name) || { name, unit: "", type: "numeric" });
        }

        function summarize(channel, selected) {
            const fields = definitionsFor(channel);
            const stats = fields.map(field => {
                const items = selected.filter(item => item.parameterName === field.name);
                const values = items.map(item => Number(item.value)).filter(Number.isFinite);
                if (!values.length) return { field: field.name, unit: field.unit || "", count: items.length, min: null, max: null, avg: null, median: null, stdDev: null };
                const sorted = [...values].sort((a, b) => a - b);
                const avg = values.reduce((sum, value) => sum + value, 0) / values.length;
                const median = sorted.length % 2 ? sorted[(values.length - 1) / 2] : (sorted[values.length / 2 - 1] + sorted[values.length / 2]) / 2;
                const stdDev = Math.sqrt(values.reduce((sum, value) => sum + (value - avg) ** 2, 0) / values.length);
                return { field: field.name, unit: field.unit || "", count: values.length, min: sorted[0], max: sorted.at(-1), avg, median, stdDev };
            });
            const stateField = fields.find(field => field.type === "state" || /state|status|on.?off/i.test(field.name));
            const luxField = fields.find(field => field.type !== "state" && /lux|light/i.test(`${field.name} ${field.unit}`));
            const stateReadings = stateField ? selected.filter(item => item.parameterName === stateField.name).map(item => ({ ...item, on: isOn(item) })).sort(byTime) : [];
            let onMs = 0; let switches = 0; let onLux = [];
            stateReadings.forEach((item, index) => {
                const start = new Date(item.timestamp).getTime();
                const stop = index + 1 < stateReadings.length ? new Date(stateReadings[index + 1].timestamp).getTime() : Math.min(Date.now(), endBound());
                if (index && item.on !== stateReadings[index - 1].on) switches += 1;
                if (item.on && stop > start) {
                    onMs += stop - start;
                    if (luxField) onLux.push(...selected.filter(reading => reading.parameterName === luxField.name && new Date(reading.timestamp).getTime() >= start && new Date(reading.timestamp).getTime() < stop).map(reading => Number(reading.value)).filter(Number.isFinite));
                }
            });
            const onHours = onMs / 3600000;
            const wattage = Number(channel?.alertSettings?.wattage ?? 40);
            const tariff = Number(channel?.alertSettings?.tariffPerKwh ?? 8);
            const energyKwh = onHours * wattage / 1000;
            const avgLuxOn = onLux.length ? onLux.reduce((sum, value) => sum + value, 0) / onLux.length : null;
            const luxValues = selected.filter(item => item.parameterName === luxField?.name && Number.isFinite(Number(item.value)) && (!stateField || stateReadings.some(state => state.on && new Date(state.timestamp) <= new Date(item.timestamp)))).map(item => Number(item.value));
            const health = !stateField ? "State field unavailable" : !stateReadings.length ? "No state samples" : avgLuxOn === null ? "Insufficient light samples" : avgLuxOn < Number(channel?.alertSettings?.dimThresholdLux ?? 200) ? "Needs inspection: low average ON brightness" : "Operating within configured brightness threshold";
            return { fields: stats, stateField: stateField?.name || null, luxField: luxField?.name || null, onHours, switches, avgLuxOn, energyKwh, tariffCost: energyKwh * tariff, wattage, tariff, health, simulated: Boolean(channel?.isSimulated), lightMin: luxValues.length ? Math.min(...luxValues) : null, lightMax: luxValues.length ? Math.max(...luxValues) : null };
        }

        function endBound() {
            const value = document.getElementById("endDate").value;
            return value ? new Date(`${value}T23:59:59.999`).getTime() : Date.now();
        }

        function selectedAlerts(channel, selected) {
            const times = selected.map(reading => new Date(reading.timestamp).getTime()).filter(Number.isFinite);
            const startDate = document.getElementById("startDate").value;
            const endDate = document.getElementById("endDate").value;
            const start = startDate ? new Date(`${startDate}T00:00:00`).getTime() : (times.length ? Math.min(...times) : -Infinity);
            const end = endDate ? new Date(`${endDate}T23:59:59.999`).getTime() : (times.length ? Math.max(...times) : Infinity);
            return allAlerts.filter(alert => (alert.channelId === channel?.id || alert.deviceId === channel?.id) && new Date(alert.timestamp || 0).getTime() >= start && new Date(alert.timestamp || 0).getTime() <= end);
        }

        function insightLines(channel, model) {
            const saved = savedReportItems.filter(item => !item.channelId || item.channelId === channel?.id).map(item => item.text);
            const generated = model.fields.filter(field => field.avg !== null).map(field => `${field.field}: average ${field.avg.toFixed(2)}${field.unit ? ` ${field.unit}` : ""}; range ${field.min.toFixed(2)}–${field.max.toFixed(2)}.`);
            return [...saved, ...generated];
        }

        function model() {
            const channel = channelById(deviceSelect.value);
            const selected = readingsInRange(channel);
            const metrics = summarize(channel, selected);
            const alerts = selectedAlerts(channel, selected);
            const dates = selected.map(item => new Date(item.timestamp)).filter(date => Number.isFinite(date.getTime()));
            const fields = definitionsFor(channel);
            const graphs = fields.filter(field => selected.some(item => item.parameterName === field.name && (Number.isFinite(Number(item.value)) || item.state || /^(on|off)$/i.test(String(item.rawValue ?? item.value)))));
            const sections = [...document.querySelectorAll("[name=reportSection]:checked")].map(input => input.value);
            const enabledGraphs = graphChecks.size ? [...graphChecks].filter(([, enabled]) => enabled).map(([name]) => name) : graphs.map(field => field.name);
            const dateRange = { start: document.getElementById("startDate").value || (dates.length ? new Date(Math.min(...dates)).toISOString().slice(0, 10) : ""), end: document.getElementById("endDate").value || (dates.length ? new Date(Math.max(...dates)).toISOString().slice(0, 10) : "") };
            const selectedGraphs = graphs.filter(field => enabledGraphs.includes(field.name));
            const result = { title: "IoT Insight Channel Report", generatedAt: new Date().toISOString(), dateRange, channel: channel ? { id: channel.id, name: channel.name || channel.deviceName || channel.id, location: channel.location || "", simulated: Boolean(channel.isSimulated), status: channel.status || "unknown" } : null, user, selected, metrics, alerts, insights: [], graphs: selectedGraphs, graphOptions: graphs, sections, empty: selected.length === 0 };
            result.insights = insightLines(channel, result);
            return result;
        }

        function render() {
            const report = model();
            reportCharts.forEach(chart => chart.destroy()); reportCharts = [];
            document.getElementById("reportsSimulatedBadge")?.classList.toggle("hidden", !report.channel?.simulated);
            parameterSelect.innerHTML = `<option value="">All parameters</option>${definitionsFor(channelById(deviceSelect.value)).map(field => `<option value="${escapeHtml(field.name)}">${escapeHtml(field.name)}</option>`).join("")}`;
            if (parameterSelect.value && !definitionsFor(channelById(deviceSelect.value)).some(field => field.name === parameterSelect.value)) parameterSelect.value = "";
            graphSelection.innerHTML = `<legend>Include graphs <span class="muted">(untick graphs you do not need)</span></legend>${report.graphOptions.map(field => `<label><input type="checkbox" name="reportGraph" value="${escapeHtml(field.name)}" ${graphChecks.get(field.name) !== false ? "checked" : ""}> ${escapeHtml(field.name)} trend</label>`).join("") || '<div class="muted">No charts are available for this selection.</div>'}`;
            graphSelection.querySelectorAll("[name=reportGraph]").forEach(input => input.addEventListener("change", () => { graphChecks.set(input.value, input.checked); render(); }));
            const summaryRows = report.metrics.fields.map(field => `<tr><td>${escapeHtml(field.field)}</td><td>${field.count}</td><td>${formatNumber(field.min, field.unit)}</td><td>${formatNumber(field.max, field.unit)}</td><td>${formatNumber(field.avg, field.unit)}</td><td>${formatNumber(field.median, field.unit)}</td><td>${formatNumber(field.stdDev, field.unit)}</td></tr>`).join("");
            const alertsRows = report.alerts.map(alert => `<tr><td>${escapeHtml(formatDate(alert.timestamp))}</td><td>${escapeHtml(alert.type || "Alert")}</td><td>${escapeHtml(alert.severity || "")}</td><td>${escapeHtml(alert.status || "")}</td><td>${escapeHtml(alert.message || "")}</td></tr>`).join("");
            const reportHtml = `<article class="report-document ${report.channel?.simulated ? "report-simulated" : ""}">
                <header class="report-cover"><div class="report-brand">IoT INSIGHT ${report.channel?.simulated ? '<span class="simulated-badge">SIMULATED DATA</span>' : ""}</div><h2>${escapeHtml(report.title)}</h2><p><strong>Channel:</strong> ${escapeHtml(report.channel?.name || "No channel selected")} ${report.channel?.location ? `· ${escapeHtml(report.channel.location)}` : ""}</p><p><strong>Date range:</strong> ${escapeHtml(report.dateRange.start || "No readings")} to ${escapeHtml(report.dateRange.end || "No readings")}</p><p><strong>Generated:</strong> ${escapeHtml(formatDate(report.generatedAt))}</p><p><strong>User:</strong> ${escapeHtml(report.user)}</p></header>
                ${report.empty ? '<div class="report-empty"><h3>No data in this date range</h3><p>Choose another channel or expand the date range. You can still download this empty report.</p></div>' : `${report.sections.includes("summary") ? `<section class="report-section"><h3>Summary statistics</h3><p>${report.selected.length} field readings across ${report.metrics.fields.filter(field => field.count).length} parameter(s).</p><div class="table-wrapper"><table><thead><tr><th>Parameter</th><th>Samples</th><th>Min</th><th>Max</th><th>Average</th><th>Median</th><th>Std dev</th></tr></thead><tbody>${summaryRows}</tbody></table></div></section>` : ""}
                ${report.sections.includes("tube") ? `<section class="report-section"><h3>Tube-light summary</h3><div class="report-metric-grid"><div><span>ON hours</span><strong>${report.metrics.onHours.toFixed(2)}</strong></div><div><span>Switches</span><strong>${report.metrics.switches}</strong></div><div><span>Average lux while ON</span><strong>${report.metrics.avgLuxOn === null ? "—" : `${report.metrics.avgLuxOn.toFixed(1)} lux`}</strong></div><div><span>Energy estimate</span><strong>${report.metrics.energyKwh.toFixed(3)} kWh</strong></div><div><span>Estimated cost</span><strong>₹${report.metrics.tariffCost.toFixed(2)}</strong></div><div><span>Health</span><strong>${escapeHtml(report.metrics.health)}</strong></div></div><p>Estimate uses ${report.metrics.wattage} W and ₹${report.metrics.tariff}/kWh. ${report.metrics.lightMin === null ? "" : `Observed light range: ${report.metrics.lightMin.toFixed(1)}–${report.metrics.lightMax.toFixed(1)} lux.`}</p></section>` : ""}
                ${report.sections.includes("visualizations") ? `<section class="report-section"><h3>Charts</h3><div id="reportGraphHost" class="report-graph-host"></div></section>` : ""}
                ${report.sections.includes("insights") ? `<section class="report-section"><h3>Insights</h3><ul>${report.insights.length ? report.insights.map(line => `<li>${escapeHtml(line)}</li>`).join("") : "<li>No saved or generated insights for this selection.</li>"}</ul></section>` : ""}
                ${report.sections.includes("alerts") ? `<section class="report-section"><h3>Alerts</h3>${report.alerts.length ? `<div class="table-wrapper"><table><thead><tr><th>Time</th><th>Alert</th><th>Severity</th><th>Status</th><th>Details</th></tr></thead><tbody>${alertsRows}</tbody></table></div>` : "<p>No alerts in this date range.</p>"}</section>` : ""}`}
                </article>`;
            preview.innerHTML = reportHtml;
            const graphHost = document.getElementById("reportGraphHost");
            if (graphHost && typeof Chart !== "undefined") report.graphs.forEach((field, index) => {
                const items = report.selected.filter(item => item.parameterName === field.name && (Number.isFinite(Number(item.value)) || item.state || /^(on|off)$/i.test(String(item.rawValue ?? item.value))));
                if (!items.length) return;
                const card = document.createElement("section"); card.className = "chart-card report-chart-card"; card.innerHTML = `<h4>${escapeHtml(field.name)}</h4><canvas id="report-chart-${index}"></canvas>`; graphHost.append(card);
                const chart = createTimeSeriesChart(card.querySelector("canvas"), items, { parameterName: field.name, unit: field.unit || "", colorIndex: index, fill: true, yTitle: field.name, stepped: field.type === "state" });
                addChartControls(chart, card); if (chart) reportCharts.push(chart);
            });
            message.textContent = report.empty ? "No readings match this selection; the report can still be downloaded." : "Report preview updated.";
            message.classList.remove("hidden");
            message.classList.toggle("error", false);
        }

        async function exportPdf() {
            if (!window.jspdf?.jsPDF || !window.html2canvas) throw new Error("PDF libraries did not load. Check the network and reload Reports.");
            render();
            const source = preview.querySelector(".report-document");
            const canvas = await window.html2canvas(source, { scale: 2, backgroundColor: "#ffffff", useCORS: true, width: source.scrollWidth, windowWidth: Math.max(source.scrollWidth, 900) });
            const pdf = new window.jspdf.jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
            const pageWidth = pdf.internal.pageSize.getWidth(); const pageHeight = pdf.internal.pageSize.getHeight();
            const margin = 12; const imageWidth = pageWidth - margin * 2; const imageHeight = canvas.height * imageWidth / canvas.width;
            const pageCanvas = document.createElement("canvas"); pageCanvas.width = canvas.width; pageCanvas.height = Math.floor(canvas.width * (pageHeight - margin * 2) / imageWidth);
            const context = pageCanvas.getContext("2d"); let offset = 0; let page = 0;
            while (offset < canvas.height) {
                context.fillStyle = "#ffffff"; context.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
                context.drawImage(canvas, 0, offset, canvas.width, Math.min(pageCanvas.height, canvas.height - offset), 0, 0, canvas.width, Math.min(pageCanvas.height, canvas.height - offset));
                if (page) pdf.addPage();
                const slice = pageCanvas.toDataURL("image/jpeg", 0.92);
                pdf.addImage(slice, "JPEG", margin, margin, imageWidth, pageHeight - margin * 2, undefined, "FAST");
                offset += pageCanvas.height; page += 1;
            }
            pdf.save("iot-insight-report.pdf");
        }

        function exportCsv() {
            const report = model();
            const rows = [["# Report", report.title], ["# Channel", report.channel?.name || ""], ["# User", report.user], ["# Date range", `${report.dateRange.start} to ${report.dateRange.end}`], ["# Generated", report.generatedAt], ["# Simulated", report.metrics.simulated ? "YES" : "NO"], [], ["Summary", "Samples", "Min", "Max", "Average", "Median", "Std dev"], ...report.metrics.fields.map(field => [field.field, field.count, field.min ?? "", field.max ?? "", field.avg ?? "", field.median ?? "", field.stdDev ?? ""]), [], ["Tube ON hours", report.metrics.onHours], ["Switches", report.metrics.switches], ["Average lux while ON", report.metrics.avgLuxOn ?? ""], ["Energy kWh", report.metrics.energyKwh], ["Estimated cost", report.metrics.tariffCost], ["Health", report.metrics.health], [], ["Alert time", "Type", "Severity", "Status", "Details"], ...report.alerts.map(alert => [alert.timestamp, alert.type, alert.severity, alert.status, alert.message]), [], ["Insights"], ...report.insights.map(line => [line]), [], ["Reading timestamp", "Channel", "Parameter", "Value", "Unit", "State", "Entry ID"], ...report.selected.map(item => [item.timestamp, report.channel?.name || "", item.parameterName, item.rawValue ?? item.value, item.unit || "", item.state || "", item.entryId ?? ""])];
            download("iot-insight-report.csv", rows.map(row => row.map(csvCell).join(",")).join("\r\n"), "text/csv;charset=utf-8");
        }

        function exportXlsx() {
            if (!window.XLSX) throw new Error("SheetJS did not load. Check the network and reload Reports.");
            const report = model(); const workbook = XLSX.utils.book_new();
            const cover = [["IoT Insight Channel Report"], ["Channel", report.channel?.name || ""], ["Location", report.channel?.location || ""], ["User", report.user], ["Date range start", report.dateRange.start], ["Date range end", report.dateRange.end], ["Generated", report.generatedAt], ["Simulated data", report.metrics.simulated ? "YES" : "NO"], ["Readings", report.selected.length]];
            XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet(cover), "Cover");
            XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(report.metrics.fields), "Summary stats");
            XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([["ON hours", report.metrics.onHours], ["Switches", report.metrics.switches], ["Average lux while ON", report.metrics.avgLuxOn], ["Energy kWh", report.metrics.energyKwh], ["Estimated cost", report.metrics.tariffCost], ["Health", report.metrics.health]]), "Tube summary");
            XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(report.insights.map(text => ({ insight: text }))), "Insights");
            XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(report.alerts.map(alert => ({ time: alert.timestamp, type: alert.type, severity: alert.severity, status: alert.status, details: alert.message }))), "Alerts");
            XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(report.selected.map(item => ({ timestamp: item.timestamp, channel: report.channel?.name || "", parameter: item.parameterName, value: item.rawValue ?? item.value, unit: item.unit || "", state: item.state || "", entry_id: item.entryId ?? "" }))), "Readings");
            XLSX.writeFile(workbook, "iot-insight-report.xlsx");
        }

        function exportJson() {
            const report = model();
            const output = { ...report, selected: report.selected.map(item => ({ timestamp: item.timestamp, channelId: item.channelId || report.channel?.id || "", parameter: item.parameterName, value: item.rawValue ?? item.value, unit: item.unit || "", state: item.state || "", entry_id: item.entryId ?? null })), charts: report.graphs.map(field => ({ parameter: field.name, unit: field.unit || "", points: report.selected.filter(item => item.parameterName === field.name).map(item => ({ timestamp: item.timestamp, value: item.rawValue ?? item.value, state: item.state || "" })) })) };
            download("iot-insight-report.json", JSON.stringify(output, null, 2), "application/json;charset=utf-8");
        }

        function runExport(action) { try { Promise.resolve(action()).catch(error => showExportError(error)); } catch (error) { showExportError(error); } }
        function showExportError(error) { message.textContent = error.message || "Could not create the report."; message.classList.remove("hidden"); message.classList.add("error"); }
        form.addEventListener("submit", event => { event.preventDefault(); render(); });
        document.querySelectorAll("[name=reportSection], #reportParameter, #reportDevice, #startDate, #endDate").forEach(input => input.addEventListener("change", render));
        document.getElementById("downloadPdf").addEventListener("click", () => runExport(exportPdf));
        document.getElementById("downloadCsv").addEventListener("click", exportCsv);
        document.getElementById("downloadXlsx").addEventListener("click", exportXlsx);
        document.getElementById("downloadJson").addEventListener("click", exportJson);
        render();
    } catch (error) { showDataError(error); preview.innerHTML = `<div class="report-empty"><h3>Report unavailable</h3><p>${escapeHtml(error.message)}</p></div>`; }
});

function isOn(item) { return item.state === "ON" || item.state === "1" || String(item.rawValue ?? item.value).toLowerCase() === "on" || String(item.rawValue ?? item.value).toLowerCase() === "true" || Number(item.value) === 1; }
function byTime(a, b) { return new Date(a.timestamp) - new Date(b.timestamp); }
function formatNumber(value, unit = "") { return value === null || !Number.isFinite(value) ? "—" : `${value.toFixed(2)}${unit ? ` ${unit}` : ""}`; }
function csvCell(value) { const text = String(value ?? ""); return `"${text.replaceAll('"', '""')}"`; }
function download(name, content, type) { const url = URL.createObjectURL(new Blob([content], { type })); const link = document.createElement("a"); link.href = url; link.download = name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); }
async function currentUserLabel(uid) { return uid || "Signed-in user"; }
function escapeHtml(value) { return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;"); }
