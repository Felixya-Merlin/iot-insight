/* Firebase Web App configuration. This file is deployed to Hosting and is public. */
export const firebaseConfig = {
    apiKey: "AIzaSyDYa-T-OJzZYC5kcIge3YaP2tC1BCh1LVs",
    authDomain: "iot-insight.firebaseapp.com",
    projectId: "iot-insight",
    databaseURL: "",
    storageBucket: "iot-insight.firebasestorage.app",
    messagingSenderId: "1090600142616",
    appId: "1:1090600142616:web:3ceec3c1a382793a69406d",
    measurementId: "G-GHYB7G0SZN"
};
