import { loadFirebaseData, showDataError } from "./firebase-data.js";
import { getChannelSettings, saveChannel, saveChannelParameter } from "./firebase-service.js";

document.addEventListener("DOMContentLoaded", async () => {
    const body = document.getElementById("parameterTableBody");
    const modal = document.getElementById("parameterModal");
    const form = document.getElementById("parameterForm");
    try {
        let data = await loadFirebaseData();
        let originalParameters = data.parameters || [];
        const render = () => {
            const { readings = [], devices = [] } = data;
            const channelFields = devices.filter(device => device.channelType === "channel").flatMap(device => Object.values(device.fields || {}).map(field => ({ ...field, id: `${device.id}_${field.fieldKey}`, parameterId: `${device.id}_${field.fieldKey}`, channelId: device.id, deviceId: device.id, parameterName: field.name, unit: field.unit, type: field.type })));
            const merged = new Map(originalParameters.map(parameter => [parameter.id || parameter.parameterId, parameter]));
            channelFields.forEach(parameter => { if (!merged.has(parameter.id)) merged.set(parameter.id, parameter); });
            const parameters = [...merged.values()];
            document.getElementById("parameterCount").textContent = `${parameters.length} Parameter${parameters.length === 1 ? "" : "s"}`;
            document.getElementById("parameterEmptyState").style.display = parameters.length ? "none" : "block";
            body.innerHTML = parameters.map(parameter => {
                const values = readings.filter(reading => reading.parameterName === parameter.parameterName).map(reading => Number(reading.value)).filter(Number.isFinite);
                const device = devices.find(item => item.deviceId === parameter.deviceId || item.id === parameter.deviceId);
                return `<tr><td>${escape(parameter.parameterName)}</td><td>${escape(parameter.unit || parameter.type || "Detected")}</td><td>${escape(device?.deviceName || parameter.deviceId)}</td><td>${values.length ? Math.min(...values).toFixed(2) : "Categorical"}</td><td>${values.length ? Math.max(...values).toFixed(2) : "Categorical"}</td><td>${escape(parameter.description || "Configured")}</td><td><button type="button" data-edit-parameter="${escape(parameter.id || parameter.parameterId)}">Edit</button></td></tr>`;
            }).join("");
        };
        const deviceSelect = document.getElementById("parameterDevice");
        const channels = data.devices.filter(device => device.channelType === "channel");
        deviceSelect.innerHTML = channels.map(channel => `<option value="${escape(channel.id)}">${escape(channel.name || channel.deviceName)}</option>`).join("");
        render();
        const close = () => modal.classList.remove("active");
        document.getElementById("addParameterButton").addEventListener("click", () => { form.reset(); document.getElementById("parameterName").dataset.fieldKey = ""; modal.classList.add("active"); });
        document.getElementById("closeParameterModal").addEventListener("click", close);
        document.getElementById("cancelParameter").addEventListener("click", close);
        body.addEventListener("click", async event => {
            const button = event.target.closest("[data-edit-parameter]");
            if (!button) return;
            const parameter = data.parameters.find(item => (item.id || item.parameterId) === button.dataset.editParameter);
            if (!parameter) return;
            document.getElementById("parameterName").value = parameter.parameterName;
            document.getElementById("parameterName").dataset.fieldKey = parameter.fieldName || "";
            document.getElementById("parameterUnit").value = parameter.unit || "";
            document.getElementById("parameterType").value = parameter.type === "state" ? "state" : "numeric";
            document.getElementById("parameterDevice").value = parameter.channelId || parameter.deviceId;
            document.getElementById("minimumThreshold").value = parameter.minValue ?? 0;
            document.getElementById("maximumThreshold").value = parameter.maxValue ?? 0;
            document.getElementById("parameterDescription").value = parameter.description || "";
            modal.classList.add("active");
        });
        form.addEventListener("submit", async event => {
            event.preventDefault();
            const channelId = deviceSelect.value;
            const existingKey = document.getElementById("parameterName").dataset.fieldKey;
            const name = document.getElementById("parameterName").value.trim();
            const unit = document.getElementById("parameterUnit").value.trim();
            const type = document.getElementById("parameterType").value;
            const minValue = Number(document.getElementById("minimumThreshold").value);
            const maxValue = Number(document.getElementById("maximumThreshold").value);
            try {
                const channel = await getChannelSettings(channelId);
                if (channel.channelType !== "channel") throw new Error("Parameters can be edited here for channel fields. Configure imported datasets through Data Import.");
                if (existingKey) await saveChannelParameter(channelId, existingKey, { name, unit, type, minValue, maxValue, description: document.getElementById("parameterDescription").value.trim() });
                else {
                    const fields = Object.values(channel.fields || {});
                    if (fields.length >= 8) throw new Error("Channels support at most 8 fields.");
                    const fieldKey = Array.from({ length: 8 }, (_, index) => `field${index + 1}`).find(key => !channel.fields?.[key]);
                    await saveChannel({ ...channel, fields: [...fields, { fieldKey, name, unit, type, minValue, maxValue, description: document.getElementById("parameterDescription").value.trim() }] });
                }
                data = await loadFirebaseData(); originalParameters = data.parameters || []; render(); close();
            } catch (error) { window.alert(error.message); }
        });
    } catch (error) { showDataError(error); }
});

function escape(value) { return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;"); }
