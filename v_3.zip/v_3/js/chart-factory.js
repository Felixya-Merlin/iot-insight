const CHART_COLORS = ["#27705e", "#2563eb", "#d97706", "#b42318", "#7c3aed", "#0891b2"];
const USER_TIME_ZONE = () => localStorage.getItem("iot-insight-timezone") || "Asia/Kolkata";

export function createTimeSeriesChart(canvas, readings, options = {}) {
    if (!canvas || typeof Chart === "undefined") return null;
    const points = readings
        .filter(item => item.timestamp && (Number.isFinite(Number(item.value)) || /^(on|off)$/i.test(String(item.state || item.rawValue || item.value))))
        .map(item => {
            const raw = item.state || item.rawValue || item.value;
            const categoricalState = /^(on|off)$/i.test(String(raw));
            return { x: new Date(item.timestamp), y: categoricalState ? (/^on$/i.test(String(raw)) ? 1 : 0) : Number(item.value), reading: item };
        })
        .filter(item => Number.isFinite(item.x.getTime()))
        .sort((a, b) => a.x - b.x);
    if (!points.length) return null;

    const parameterName = options.parameterName || points[0].reading.parameterName || "Value";
    const unit = options.unit || window.iotParameterUnits?.[parameterName] || points.find(point => point.reading.unit)?.reading.unit || "";
    const state = options.stepped ?? (points.some(point => point.reading.state || /^(on|off)$/i.test(String(point.reading.rawValue ?? point.reading.value))) || /state|status|on.?off/i.test(parameterName));
    const color = options.color || CHART_COLORS[options.colorIndex % CHART_COLORS.length] || CHART_COLORS[0];
    const times = points.map(point => point.x.getTime());
    const span = points[points.length - 1].x.getTime() - points[0].x.getTime();
    const timeFormat = span < 86400000 ? "h:mm a" : "d MMM";
    const chart = new Chart(canvas, {
        type: "line",
        data: {
            datasets: [{
                label: parameterName,
                data: points.map(point => ({ x: point.x, y: point.y, reading: point.reading })),
                borderColor: color,
                backgroundColor: options.fill ? `${color}26` : "transparent",
                borderWidth: 2,
                tension: state ? 0 : (options.tension ?? 0.25),
                stepped: state ? "after" : false,
                fill: Boolean(options.fill),
                spanGaps: true,
                pointRadius: points.length > 200 ? 0 : (options.pointRadius ?? 2),
                pointHoverRadius: 6,
                pointHitRadius: 18
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            parsing: false,
            interaction: { mode: "nearest", intersect: false },
            plugins: {
                legend: { display: options.legend ?? true, position: "bottom" },
                decimation: { enabled: points.length > 200, algorithm: "min-max" },
                zoom: {
                    pan: { enabled: true, mode: "x", threshold: 4 },
                    zoom: { drag: { enabled: true }, wheel: { enabled: true }, pinch: { enabled: true }, mode: "x" }
                },
                tooltip: {
                    callbacks: {
                        title(items) {
                            const reading = items[0]?.raw?.reading;
                            const date = reading?.timestamp ? new Date(reading.timestamp) : new Date(items[0]?.parsed.x);
                            return date.toLocaleString([], { year: "numeric", month: "short", day: "numeric", hour: "numeric", minute: "2-digit", second: "2-digit", timeZone: USER_TIME_ZONE() });
                        },
                        label(context) {
                            const reading = context.raw?.reading;
                            const name = reading?.parameterName || parameterName;
                            const value = reading?.rawValue ?? reading?.value ?? context.parsed.y;
                            const fieldUnit = window.iotParameterUnits?.[name] || unit;
                            return `${name}: ${value}${fieldUnit ? ` ${fieldUnit}` : ""}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    type: "time",
                    time: { displayFormats: { minute: "h:mm a", hour: "h:mm a", day: "d MMM", week: "d MMM", month: "d MMM" } },
                    ticks: { autoSkip: true, maxTicksLimit: options.maxTicksLimit || 7, maxRotation: 0, minRotation: 0, color: "#64748b", callback(value) { const date = new Date(value); return span < 86400000 ? date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit", timeZone: USER_TIME_ZONE() }) : date.toLocaleDateString([], { day: "numeric", month: "short", timeZone: USER_TIME_ZONE() }); } },
                    grid: { display: false }
                },
                y: {
                    title: { display: Boolean(options.yTitle), text: options.yTitle || parameterName },
                    ticks: { maxTicksLimit: 5, color: "#64748b" },
                    grid: { color: "rgba(148, 163, 184, 0.12)" }
                }
            }
        }
    });
    chart.$timeSpan = span;
    chart.$timeExtent = [times[0], times[times.length - 1]];
    return chart;
}

export function addChartControls(chart, container) {
    if (!chart || !container) return;
    const controls = document.createElement("div");
    controls.className = "chart-controls";
    controls.innerHTML = `<div class="chart-range-buttons" aria-label="Chart time range"><button type="button" data-range="1h">1h</button><button type="button" data-range="24h">24h</button><button type="button" data-range="7d">7d</button><button type="button" data-range="all">All</button></div><button type="button" data-reset-zoom>Reset zoom</button>`;
    container.querySelector(":scope > .chart-controls")?.remove();
    controls.addEventListener("click", event => {
        const rangeButton = event.target.closest("[data-range]");
        if (rangeButton) {
            const range = rangeButton.dataset.range;
            if (range === "all") chart.resetZoom();
            else {
                const duration = ({ "1h": 3600000, "24h": 86400000, "7d": 604800000 })[range];
                const latest = chart.$timeExtent[1];
                chart.options.scales.x.min = latest - duration;
                chart.options.scales.x.max = latest;
                chart.update("none");
            }
        }
        if (event.target.closest("[data-reset-zoom]")) {
            delete chart.options.scales.x.min;
            delete chart.options.scales.x.max;
            chart.resetZoom();
        }
    });
    container.prepend(controls);
}
