import { loadFirebaseData, showDataError } from "./firebase-data.js";
import { subscribeToUserMonitoring } from "./firebase-service.js";
import { createTimeSeriesChart, addChartControls } from "./chart-factory.js";

document.addEventListener("DOMContentLoaded", async () => {
    let data;
    try { data = await loadFirebaseData(); } catch (error) { showDataError(error); return; }
    let { devices = [], readings = [], parameters = [] } = data;
    window.iotParameterUnits = Object.fromEntries(parameters.map(item => [item.parameterName, item.unit || ""]));
    const requestedId = new URLSearchParams(window.location.search).get("id");
    const device = devices.find(item => item.deviceId === requestedId || item.id === requestedId) || devices[0];
    if (!device) {
        const host = document.querySelector(".page-content") || document.querySelector("main");
        if (host) host.innerHTML = `<div class="page-state-empty"><h2>Channel unavailable</h2><p>The selected channel could not be found or is not accessible to this account.</p><a class="btn btn-primary" href="channels.html">Open Channels</a></div>`;
        return;
    }

    let chart = null;
    let detailReadings = [];
    function render() {
        const deviceId = device.deviceId || device.id;
        detailReadings = readings.filter(reading => reading.deviceId === deviceId || reading.channelId === device.id).sort(sortByDate);
        const configuredStateName = Object.values(device.fields || {}).find(field => field.type === "state")?.name;
        const configuredStateKey = Object.values(device.fields || {}).find(field => field.type === "state")?.fieldKey;
        const states = detailReadings.filter(reading => reading.state || ((reading.parameterName === configuredStateName || reading.fieldName === configuredStateKey) && [0, 1].includes(Number(reading.value)))).map(reading => ({ ...reading, state: reading.state || (Number(reading.value) === 1 ? "ON" : "OFF") }));
        const latestState = states[states.length - 1];
        const preferredDefinition = Object.values(device.fields || {}).find(field => field.type === "numeric") || Object.values(device.fields || {})[0];
        const preferredField = preferredDefinition?.name;
        const configuredReadings = preferredField ? detailReadings.filter(reading => reading.parameterName === preferredField) : detailReadings;
        const primaryReadings = configuredReadings.length ? configuredReadings : detailReadings;
        const numericLatest = [...primaryReadings].reverse().find(reading => preferredDefinition?.type !== "state" && !reading.state && reading.value !== "" && Number.isFinite(Number(reading.value)));
        const latest = numericLatest || primaryReadings[primaryReadings.length - 1] || detailReadings[detailReadings.length - 1];
        const onCount = states.filter(reading => reading.state === "ON").length;
        const changes = states.slice(1).filter((reading, index) => reading.state !== states[index].state).length;

        setText("deviceDetailName", device.deviceName || device.name || "Device");
        setText("deviceDetailId", deviceId);
        setText("detailDeviceId", deviceId);
        setText("detailDeviceLocation", device.location || "Not specified");
        const primaryDefinition = preferredDefinition || Object.values(device.fields || {})[0];
        setText("detailPrimaryParameter", primaryDefinition?.name || detailReadings[0]?.parameterName || "—");
        setText("detailPrimaryType", primaryDefinition ? `${primaryDefinition.type || "numeric"}${primaryDefinition.unit ? ` · ${primaryDefinition.unit}` : ""}` : "—");
        setText("lightState", latestState?.state || latest?.parameterName || "Waiting for reading...");
        const unit = latest ? (window.iotParameterUnits[latest.parameterName] || preferredDefinition?.unit || "") : "";
        setText("lightValue", latest ? `${latest.parameterName}: ${latest.rawValue ?? latest.value}${unit ? ` ${unit}` : ""}` : "Waiting for reading...");
        setText("deviceLastSeen", formatDateTime(device.lastSeenAt || latest?.timestamp));
        setText("totalReadings", detailReadings.length);
        setText("onCount", onCount);
        setText("offCount", states.length - onCount);
        setText("onPercentage", `${states.length ? (onCount / states.length * 100).toFixed(1) : 0}%`);
        setText("statusChanges", changes);
        updateConnectionStatus(device);
        updateGauge(latest, primaryReadings);

        chart?.destroy();
        const container = document.getElementById("readingHistoryChart")?.closest(".chart-container");
        container?.querySelector(":scope > .chart-controls")?.remove();
        const canvas = document.getElementById("readingHistoryChart");
        if (canvas && primaryReadings.length && typeof Chart !== "undefined") {
            chart = createTimeSeriesChart(canvas, primaryReadings, {
                parameterName: primaryReadings[0].parameterName,
                unit: window.iotParameterUnits[primaryReadings[0].parameterName],
                stepped: preferredDefinition?.type === "state" || Boolean(primaryReadings[0].state),
                color: "#0f766e"
            });
            addChartControls(chart, container);
            document.getElementById("readingHistoryEmpty")?.classList.add("hidden");
        } else {
            chart = null;
            document.getElementById("readingHistoryEmpty")?.classList.remove("hidden");
        }
    }

    render();
    try {
        const unsubscribe = await subscribeToUserMonitoring(snapshot => {
            devices = snapshot.devices;
            readings = snapshot.readings;
            const updatedDevice = devices.find(item => item.id === device.id || item.deviceId === device.deviceId);
            if (updatedDevice) Object.assign(device, updatedDevice);
            render();
        }, error => setText("deviceConnectionStatus", `Live update error: ${error.message}`));
        window.addEventListener("pagehide", unsubscribe, { once: true });
    } catch (error) { console.error("Live device updates could not start.", error); }
    setInterval(() => updateConnectionStatus(device), 15000);
});

function updateConnectionStatus(device) {
    const element = document.getElementById("deviceConnectionStatus");
    if (!element) return;
    const lastSeen = device.lastSeenAt?.toDate ? device.lastSeenAt.toDate() : new Date(device.lastSeenAt || 0);
    const online = Number.isFinite(lastSeen.getTime()) && lastSeen.getTime() > 0 && Date.now() - lastSeen.getTime() <= Math.max(1, Number(device.offlineAfterMinutes) || 5) * 60000;
    element.dataset.state = online ? "online" : "offline";
    element.innerHTML = `<span></span>${online ? "ONLINE" : "OFFLINE"}`;
    setText("deviceLastSeen", lastSeen.getTime() > 0 ? formatDateTime(lastSeen) : "No data received");
}

function updateGauge(reading, readings) {
    const meter = document.getElementById("deviceValueGauge");
    if (!meter) return;
    const values = readings.filter(item => Number.isFinite(Number(item.value))).map(item => Number(item.value));
    if (!reading || !Number.isFinite(Number(reading.value)) || !values.length) { meter.min = 0; meter.max = 1; meter.value = 0; return; }
    const min = Math.min(0, ...values);
    const max = Math.max(min + 1, ...values);
    meter.min = min; meter.max = max; meter.value = Number(reading.value);
    meter.title = `${reading.parameterName}: ${reading.rawValue ?? reading.value}${window.iotParameterUnits[reading.parameterName] ? ` ${window.iotParameterUnits[reading.parameterName]}` : ""}`;
}

function setText(id, value) { const element = document.getElementById(id); if (element) element.textContent = value; }
function sortByDate(a, b) { return new Date(a.timestamp) - new Date(b.timestamp); }
function formatDateTime(value) {
    if (!value) return "No data received";
    const date = value?.toDate ? value.toDate() : new Date(value);
    return Number.isFinite(date.getTime()) ? date.toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short", timeZone: localStorage.getItem("iot-insight-timezone") || "Asia/Kolkata" }) : "No data received";
}
