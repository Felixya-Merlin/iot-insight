import { initializeApp, getApps, getApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import { getFirestore, collection, doc, setDoc, serverTimestamp, deleteField, getDocs, getDoc, deleteDoc, runTransaction, query as firestoreQuery, where, onSnapshot } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";
import { getDatabase, limitToLast, onValue, query as databaseQuery, ref } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";
import { firebaseConfig, firebaseIsConfigured } from "./firebase-config.js";
import { connectFirebaseDatabaseEmulator, connectFirebaseEmulators, firebaseFunctionsEmulatorRequested } from "./firebase-emulator.js";

let db = null;
let authReadyPromise = null;
if (firebaseIsConfigured) {
    const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
    db = getFirestore(app);
    const auth = getAuth(app);
    connectFirebaseEmulators(auth, db);
    authReadyPromise = new Promise((resolve, reject) => {
        const unsubscribe = onAuthStateChanged(auth, user => {
            unsubscribe();
            if (user) resolve(user);
            else reject(new Error("Please sign in before accessing IoT Insight."));
        }, reject);
    });
}

export function isFirebaseReady() { return Boolean(db); }
export async function getFirebaseConnectionStatus() {
    if (!db || !authReadyPromise) return "Firebase not configured";
    try { await authReadyPromise; return "Firebase connected"; }
    catch (error) { return `Firebase authentication error: ${error.code || "unknown"}`; }
}
async function currentUser() {
    if (!db || !authReadyPromise) throw new Error("Firebase is not configured yet.");
    return authReadyPromise;
}
export async function getCurrentUserIdToken() { return (await currentUser()).getIdToken(); }
export async function getCurrentUserId() { return (await currentUser()).uid; }
function activeImportId() { return localStorage.getItem("iot-insight-active-import"); }
async function scopedCollection(name) {
    const user = await currentUser();
    const importId = activeImportId();
    const snapshot = await getDocs(firestoreQuery(collection(db, name), where("uid", "==", user.uid)));
    return snapshot.docs.map(item => ({ id: item.id, ...item.data() }))
        .filter(item => item.uid === user.uid && (!importId || item.importId === importId || item.channelType === "channel" || item.channelId));
}

function newApiKey() {
    const bytes = crypto.getRandomValues(new Uint8Array(24));
    return [...bytes].map(value => value.toString(16).padStart(2, "0")).join("");
}

function normalizeChannelField(field, index) {
    const unit = field.unit?.trim() || "";
    const fieldKey = /^field[1-8]$/.test(field.fieldKey || "") ? field.fieldKey : `field${index + 1}`;
    return { fieldKey, name: field.name?.trim() || `Field ${index + 1}`, unit, type: field.type === "state" ? "state" : "numeric", ...(field.minValue !== undefined ? { minValue: Number(field.minValue) } : /lux/i.test(unit) ? { minValue: 0 } : {}) };
}

function deviceStatus(device) {
    if (device.channelType !== "channel") return device.status || "offline";
    const lastSeen = device.lastSeenAt?.toDate ? device.lastSeenAt.toDate().getTime() : new Date(device.lastSeenAt || 0).getTime();
    const offlineAfterMinutes = Math.max(1, Number(device.offlineAfterMinutes) || 5);
    return Number.isFinite(lastSeen) && Date.now() - lastSeen <= offlineAfterMinutes * 60000 ? "online" : "offline";
}

export async function saveChannel(channel) {
    const user = await currentUser();
    const channelId = channel.id || doc(collection(db, "devices")).id;
    const existing = channel.id ? (await getDevices()).find(item => item.id === channel.id && item.channelType === "channel") : null;
    if (channel.id && (!existing || existing.ownerUid !== user.uid)) throw new Error("Channel not found or not owned by this account.");
    if (channel.fields.length > 8) throw new Error("A channel can contain no more than 8 fields.");
    const fields = channel.fields.map(normalizeChannelField);
    if (!fields.length || fields.some(field => !field.name)) throw new Error("Add at least one named field.");
    const writeApiKey = existing?.writeApiKey || newApiKey();
    const readApiKey = existing?.readApiKey || newApiKey();
    const value = {
        id: channelId, deviceId: channelId, deviceName: channel.name.trim(), name: channel.name.trim(),
        location: channel.location.trim(), ownerUid: user.uid, uid: user.uid,
        isPublic: Boolean(channel.isPublic), isSimulated: Boolean(channel.isSimulated), channelType: "channel",
        rateLimitSeconds: Math.min(86400, Math.max(15, Number(channel.rateLimitSeconds) || 15)),
        offlineAfterMinutes: Math.min(10080, Math.max(1, Number(channel.offlineAfterMinutes) || 5)),
        alertSettings: channel.alertSettings || existing?.alertSettings || {},
        fields: fields.reduce((result, field) => ({ ...result, [field.fieldKey]: field }), {}),
        writeKeyHash: await digestKey(writeApiKey), readKeyHash: await digestKey(readApiKey),
        entryCounter: existing?.entryCounter || 0, lastSeenAt: existing?.lastSeenAt || null, lastUpdateAt: existing?.lastUpdateAt || null, recentLux: existing?.recentLux || [], createdAt: existing?.createdAt || serverTimestamp(), updatedAt: serverTimestamp()
    };
    await setDoc(doc(db, "devices", channelId), value);
    await setDoc(doc(db, "channelSecrets", channelId), { ownerUid: user.uid, channelId, writeApiKey, readApiKey, updatedAt: serverTimestamp() });
    for (const field of fields) {
        const parameterId = `${channelId}_${field.fieldKey}`;
        await setDoc(doc(db, "parameters", parameterId), {
            uid: user.uid, channelId, deviceId: channelId, parameterId, parameterName: field.name,
            fieldName: field.fieldKey, unit: field.unit, type: field.type, minValue: field.minValue ?? null, maxValue: field.maxValue ?? null, description: field.description || "", updatedAt: serverTimestamp()
        });
    }
    const savedFieldKeys = new Set(fields.map(field => `${channelId}_${field.fieldKey}`));
    for (const oldField of (await getParameters()).filter(item => item.channelId === channelId && !savedFieldKeys.has(item.id))) {
        await deleteDoc(doc(db, "parameters", oldField.id));
    }
    return value;
}

export async function deleteChannel(channelId) {
    const user = await currentUser();
    const channels = await getDevices();
    const channel = channels.find(item => item.id === channelId && item.channelType === "channel");
    if (!channel || channel.ownerUid !== user.uid) throw new Error("Channel not found or not owned by this account.");
    const parameters = (await getParameters()).filter(item => item.channelId === channelId);
    for (const parameter of parameters) await deleteDoc(doc(db, "parameters", parameter.id));
    await callApi("/api/delete-channel-data", { channelId });
    await deleteDoc(doc(db, "channelSecrets", channelId));
    await deleteDoc(doc(db, "devices", channelId));
}

export async function regenerateChannelKey(channelId, keyName) {
    if (!["writeApiKey", "readApiKey"].includes(keyName)) throw new Error("Unsupported channel key.");
    const user = await currentUser();
    const channel = (await getDevices()).find(item => item.id === channelId && item.channelType === "channel");
    if (!channel || channel.ownerUid !== user.uid) throw new Error("Channel not found or not owned by this account.");
    const key = newApiKey();
    await setDoc(doc(db, "channelSecrets", channelId), { [keyName]: key, updatedAt: serverTimestamp() }, { merge: true });
    const channelRef = doc(db, "devices", channelId);
    await setDoc(channelRef, { [keyName === "writeApiKey" ? "writeKeyHash" : "readKeyHash"]: await digestKey(key), updatedAt: serverTimestamp() }, { merge: true });
    return key;
}

export async function getChannel(channelId) {
    const user = await currentUser();
    const channel = (await getDevices()).find(item => item.id === channelId && item.channelType === "channel");
    if (!channel || (!channel.isPublic && channel.ownerUid !== user.uid)) return null;
    return channel;
}

export function getIngestionUrl() {
    return `${window.location.origin}/api/update`;
}

export async function saveImportedDataset({ deviceId, deviceName, location, parameterName, unit, sourceChannelId, sourceUrl, readings }) {
    const user = await currentUser();
    if (!readings.length) throw new Error("No valid readings were found in the CSV.");
    const importRef = doc(collection(db, "imports"));
    const importId = importRef.id;
    const fields = [...new Set(readings.map(reading => reading.parameterName || parameterName).filter(Boolean))];
    const parameterIds = new Map();
    localStorage.setItem("iot-insight-active-import", importId);
    await setDoc(importRef, { importId, uid: user.uid, source: "CSV import", readingCount: readings.length, importedAt: serverTimestamp() });
    const channelId = `${importId}_${deviceId}`;
    const channelFields = Object.fromEntries(fields.slice(0, 8).map((field, index) => {
        const type = readings.some(reading => reading.parameterName === field && reading.state) ? "state" : "numeric";
        const fieldUnit = field === parameterName ? unit || "" : "";
        return [`field${index + 1}`, { fieldKey: `field${index + 1}`, name: field, unit: fieldUnit, type, ...(type === "numeric" && /lux/i.test(fieldUnit) ? { minValue: 0 } : {}) }];
    }));
    const writeApiKey = newApiKey(); const readApiKey = newApiKey();
    await setDoc(doc(db, "devices", channelId), {
        id: channelId, importId, uid: user.uid, ownerUid: user.uid, deviceId: channelId,
        deviceName, name: deviceName, location: location || "", source: "CSV import",
        isPublic: false, isSimulated: false, channelType: "channel", rateLimitSeconds: 15, offlineAfterMinutes: 5, alertSettings: {}, entryCounter: Math.max(0, ...readings.map(reading => Number(reading.entryId)).filter(Number.isFinite)),
        fields: channelFields, writeKeyHash: await digestKey(writeApiKey), readKeyHash: await digestKey(readApiKey), lastSeenAt: null, createdAt: serverTimestamp(), updatedAt: serverTimestamp()
    });
    await setDoc(doc(db, "channelSecrets", channelId), { ownerUid: user.uid, channelId, writeApiKey, readApiKey, updatedAt: serverTimestamp() });
    for (const [fieldIndex, field] of fields.slice(0, 8).entries()) {
        const parameterId = `${channelId}_field${fieldIndex + 1}`.toLowerCase().replace(/[^a-z0-9_]+/g, "_");
        parameterIds.set(field, parameterId);
        await setDoc(doc(db, "parameters", parameterId), { importId, uid: user.uid, channelId, parameterId, deviceId: channelId, parameterName: field, unit: field === parameterName ? unit || "" : "", fieldName: fieldIndex < 8 ? `field${fieldIndex + 1}` : field, sourceChannelId: sourceChannelId || "", updatedAt: serverTimestamp() });
    }
    const groupedFeeds = new Map();
    readings.forEach(reading => {
        const field = reading.parameterName || parameterName;
        const fieldKey = `field${fields.indexOf(field) + 1}`;
        if (!channelFields[fieldKey]) return;
        const timestamp = feedTimestamp(reading.timestamp);
        const sourceEntryId = String(reading.entryId || timestamp);
        const key = `${sourceEntryId}:${timestamp}`;
        if (!groupedFeeds.has(key)) groupedFeeds.set(key, { timestamp, sourceEntryId, values: {} });
        groupedFeeds.get(key).values[fieldKey] = { value: reading.value, state: reading.state || "", rawValue: String(reading.state || reading.rawValue || reading.value) };
    });
    await postImportChunks(channelId, "CSV import", sourceUrl || "", [...groupedFeeds.values()]);
    await setDoc(importRef, { deviceId, fields, sourceChannelId: sourceChannelId || "", sourceUrl: sourceUrl || "", completedAt: serverTimestamp() }, { merge: true });
    return { deviceId, importId, importedCount: readings.length };
}
export async function getAllReadings() { return (await scopedCollection("readings")).sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp)); }
export async function getRecentReadings(deviceId, parameterId, count = 100) { return (await getAllReadings()).filter(item => (!deviceId || item.deviceId === deviceId) && (!parameterId || item.parameterId === parameterId)).reverse().slice(0, count); }
export async function getDevices() {
    const devices = await scopedCollection("devices");
    return Promise.all(devices.map(async device => {
        if (device.channelType !== "channel") return { ...device, status: deviceStatus(device) };
        const secrets = await getDoc(doc(db, "channelSecrets", device.id));
        const secretValue = secrets.exists() ? secrets.data() : {};
        if (device.writeApiKey || device.readApiKey) {
            const writeApiKey = device.writeApiKey || secretValue.writeApiKey || newApiKey();
            const readApiKey = device.readApiKey || secretValue.readApiKey || newApiKey();
            await setDoc(doc(db, "channelSecrets", device.id), { ownerUid: device.ownerUid, channelId: device.id, writeApiKey, readApiKey, updatedAt: serverTimestamp() }, { merge: true });
            await setDoc(doc(db, "devices", device.id), { writeKeyHash: await digestKey(writeApiKey), readKeyHash: await digestKey(readApiKey), writeApiKey: deleteField(), readApiKey: deleteField(), updatedAt: serverTimestamp() }, { merge: true });
            return { ...device, writeApiKey, readApiKey, writeKeyHash: await digestKey(writeApiKey), readKeyHash: await digestKey(readApiKey), status: deviceStatus(device) };
        }
        return { ...device, ...secretValue, status: deviceStatus(device) };
    }));
}
export function getParameters() { return scopedCollection("parameters"); }
export async function getChannelSettings(channelId) {
    const user = await currentUser();
    if (!channelId) return {};
    const snapshot = await getDoc(doc(db, "devices", channelId));
    if (!snapshot.exists() || snapshot.data().ownerUid !== user.uid) return {};
    return snapshot.data();
}
export async function getUserSettings() {
    const user = await currentUser();
    const snapshot = await getDoc(doc(db, "users", user.uid));
    return snapshot.exists() ? (snapshot.data().settings || {}) : {};
}

export async function saveUserSettings(settings) {
    const user = await currentUser();
    await setDoc(doc(db, "users", user.uid), { uid: user.uid, settings, updatedAt: serverTimestamp() }, { merge: true });
}

export async function getCurrentChannelId() {
    const user = await currentUser();
    const snapshot = await getDoc(doc(db, "users", user.uid));
    return snapshot.exists() ? snapshot.data().activeChannelId || "" : "";
}

export async function saveActiveChannelId(channelId) {
    const user = await currentUser();
    if (channelId) {
        const channel = await getDoc(doc(db, "devices", channelId));
        if (!channel.exists() || channel.data().ownerUid !== user.uid || channel.data().channelType !== "channel") throw new Error("Select a channel owned by your account.");
    }
    await setDoc(doc(db, "users", user.uid), { uid: user.uid, activeChannelId: channelId || "", updatedAt: serverTimestamp() }, { merge: true });
}

export async function subscribeToUserPreferences(onData, onError) {
    const user = await currentUser();
    return onSnapshot(doc(db, "users", user.uid), snapshot => onData(snapshot.exists() ? snapshot.data() : {}), onError);
}

export async function getUserAlerts() {
    const user = await currentUser();
    const snapshot = await getDocs(firestoreQuery(collection(db, "alerts"), where("uid", "==", user.uid)));
    return snapshot.docs.map(item => ({ id: item.id, ...item.data() })).sort((a, b) => new Date(b.timestamp || b.updatedAt || 0) - new Date(a.timestamp || a.updatedAt || 0));
}

export async function subscribeToUserAlerts(onData, onError) {
    const user = await currentUser();
    return onSnapshot(firestoreQuery(collection(db, "alerts"), where("uid", "==", user.uid)), snapshot => {
        onData(snapshot.docs.map(item => ({ id: item.id, ...item.data() })).sort((a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0)));
    }, onError);
}

export async function updateAlertStatus(alertId, status) {
    if (!["open", "acknowledged", "resolved"].includes(status)) throw new Error("Unsupported alert status.");
    const user = await currentUser();
    const alertRef = doc(db, "alerts", alertId);
    const alert = await getDoc(alertRef);
    if (!alert.exists() || alert.data().uid !== user.uid) throw new Error("Alert not found.");
    await setDoc(alertRef, { status, ...(status === "resolved" ? { resolvedAt: serverTimestamp() } : status === "acknowledged" ? { acknowledgedAt: serverTimestamp() } : {}), updatedAt: serverTimestamp() }, { merge: true });
}

export async function saveChannelParameter(channelId, fieldKey, changes) {
    const user = await currentUser();
    const channelRef = doc(db, "devices", channelId);
    const snapshot = await getDoc(channelRef);
    if (!snapshot.exists() || snapshot.data().ownerUid !== user.uid || snapshot.data().channelType !== "channel") throw new Error("Channel not found.");
    const channel = snapshot.data();
    const existing = channel.fields?.[fieldKey];
    if (!existing) throw new Error("Channel field not found.");
    const nextField = { ...existing, ...changes, fieldKey };
    await setDoc(channelRef, { fields: { ...channel.fields, [fieldKey]: nextField }, updatedAt: serverTimestamp() }, { merge: true });
    const parameterId = `${channelId}_${fieldKey}`;
    await setDoc(doc(db, "parameters", parameterId), { uid: user.uid, channelId, deviceId: channelId, parameterId, fieldName: fieldKey, parameterName: nextField.name, unit: nextField.unit || "", type: nextField.type, minValue: nextField.minValue ?? null, maxValue: nextField.maxValue ?? null, description: nextField.description || "", updatedAt: serverTimestamp() }, { merge: true });
}

export async function subscribeToTemperatureReadings(onData, onError) {
    if (!firebaseConfig.databaseURL) throw new Error("Realtime Database is not configured.");
    const user = await currentUser();
    const realtimeDb = getDatabase(getApp(), firebaseConfig.databaseURL);
    connectFirebaseDatabaseEmulator(realtimeDb);
    return onValue(databaseQuery(ref(realtimeDb, `sensors/temperature/${user.uid}`), limitToLast(15)), snapshot => {
        const records = snapshot.val() || {};
        const readings = Object.entries(records).map(([id, record]) => ({ id, timestamp: parseTelemetryTime(record?.time), value: record?.value === null || record?.value === "" ? NaN : Number(record?.value) }))
            .filter(item => item.timestamp !== null && Number.isFinite(item.value)).sort((a, b) => a.timestamp - b.timestamp).slice(-15).map(item => ({ ...item, time: new Date(item.timestamp).toISOString() }));
        onData(readings);
    }, onError);
}

export async function callApi(path, payload) {
    const token = await getCurrentUserIdToken();
    const apiUrl = firebaseFunctionsEmulatorRequested() ? `http://127.0.0.1:5001/${firebaseConfig.projectId}/us-central1/api${path}` : `${window.location.origin}${path}`;
    const response = await fetch(apiUrl, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(payload) });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error?.message || `Request failed (${response.status}).`);
    return result;
}

async function postImportChunks(channelId, source, sourceUrl, feeds) {
    let saved = 0;
    for (let offset = 0; offset < feeds.length; offset += 60) {
        const result = await callApi("/api/import-readings", { channelId, source, sourceUrl, feeds: feeds.slice(offset, offset + 60) });
        saved += Number(result.saved || 0);
    }
    return saved;
}

async function digestKey(value) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
    return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, "0")).join("");
}

export async function setReportItem(text, metadata = {}) {
    const user = await currentUser();
    const ref = doc(db, "users", user.uid, "reports", "insights");
    const snapshot = await getDoc(ref);
    const normalized = String(text || "").trim();
    if (!normalized) return;
    await runTransaction(db, async transaction => {
        const current = await transaction.get(ref);
        const items = current.exists() ? current.data().items || [] : [];
        if (!items.some(item => item.text === normalized)) items.push({ id: stableHash(normalized), text: normalized, ...metadata, addedAt: new Date().toISOString() });
        transaction.set(ref, { uid: user.uid, items, updatedAt: serverTimestamp() }, { merge: true });
    });
}

export async function getReportItems() {
    const user = await currentUser();
    const snapshot = await getDoc(doc(db, "users", user.uid, "reports", "insights"));
    return snapshot.exists() ? snapshot.data().items || [] : [];
}

export async function subscribeToUserMonitoring(onData, onError) {
    const user = await currentUser();
    let readings = null;
    let devices = null;
    let closed = false;
    const emit = () => {
        if (!closed && readings && devices) onData({ readings, devices: devices.map(device => ({ ...device, status: deviceStatus(device) })) });
    };
    const stopReadings = onSnapshot(firestoreQuery(collection(db, "readings"), where("uid", "==", user.uid)), snapshot => {
        readings = snapshot.docs.map(item => ({ id: item.id, ...item.data() })).sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
        emit();
    }, onError);
    const stopDevices = onSnapshot(firestoreQuery(collection(db, "devices"), where("uid", "==", user.uid)), snapshot => {
        devices = snapshot.docs.map(item => ({ id: item.id, ...item.data() }));
        emit();
    }, onError);
    return () => { closed = true; stopReadings(); stopDevices(); };
}

function stableHash(value) {
    let hash = 2166136261;
    for (const character of String(value)) hash = Math.imul(hash ^ character.charCodeAt(0), 16777619);
    return (hash >>> 0).toString(16);
}

export async function saveExternalChannelFeeds(channelId, feeds, sourceUrl) {
    const user = await currentUser();
    const initial = await getDoc(doc(db, "devices", channelId));
    if (!initial.exists() || initial.data().ownerUid !== user.uid || initial.data().channelType !== "channel") throw new Error("Choose a channel owned by the signed-in account.");
    const fields = initial.data().fields || {};
    const normalizedFeeds = feeds.map(feed => ({
        timestamp: feedTimestamp(feed.timestamp), sourceEntryId: String(feed.sourceEntryId || ""),
        values: Object.fromEntries(Object.entries(feed.values).filter(([key]) => fields[key]).map(([key, item]) => [key, { value: item.value, state: item.state || "", rawValue: String(item.rawValue ?? item.value) }]))
    }));
    return postImportChunks(channelId, "URL import", sourceUrl, normalizedFeeds);
}

function feedTimestamp(value) {
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) throw new Error("A URL feed contains an invalid timestamp.");
    return date.toISOString();
}

function parseTelemetryTime(value) {
    if (typeof value === "number" && Number.isFinite(value)) {
        return value < 1e12 ? value * 1000 : value;
    }

    if (typeof value !== "string" || !value.trim()) return null;
    const numericValue = Number(value);
    if (Number.isFinite(numericValue)) return numericValue < 1e12 ? numericValue * 1000 : numericValue;

    const parsedValue = Date.parse(value);
    return Number.isFinite(parsedValue) ? parsedValue : null;
}

export async function saveDevice(device) {
    const user = await currentUser();
    const importId = activeImportId();
    if (!importId) throw new Error("Import a dataset before adding devices.");
    await setDoc(doc(db, "devices", `${importId}_${device.deviceId}`), { ...device, importId, uid: user.uid, ownerUid: user.uid, updatedAt: serverTimestamp() }, { merge: true });
    return device;
}
