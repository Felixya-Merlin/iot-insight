import { connectAuthEmulator } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";
import { connectFirestoreEmulator } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";
import { connectDatabaseEmulator } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";

function emulatorRequested() {
    const enabled = new URLSearchParams(window.location.search).get("emulator") === "1";
    if (enabled) sessionStorage.setItem("iot-insight-use-emulators", "1");
    return enabled || sessionStorage.getItem("iot-insight-use-emulators") === "1";
}

export function firebaseFunctionsEmulatorRequested() {
    return emulatorRequested();
}

export function connectFirebaseEmulators(auth, db) {
    if (!emulatorRequested()) return;
    if (auth && !window.iotAuthEmulatorConnected) {
        connectAuthEmulator(auth, "http://127.0.0.1:9099", { disableWarnings: true });
        window.iotAuthEmulatorConnected = true;
    }
    if (db && !window.iotFirestoreEmulatorConnected) {
        connectFirestoreEmulator(db, "127.0.0.1", 8080);
        window.iotFirestoreEmulatorConnected = true;
    }
}

export function connectFirebaseDatabaseEmulator(database) {
    if (!emulatorRequested() || !database || window.iotDatabaseEmulatorConnected) return;
    connectDatabaseEmulator(database, "127.0.0.1", 9000);
    window.iotDatabaseEmulatorConnected = true;
}
