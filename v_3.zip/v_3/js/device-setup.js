import { getChannel, getIngestionUrl } from "./firebase-service.js";

const host = document.getElementById("setupContent");
const channelId = new URLSearchParams(window.location.search).get("id");
function escapeHtml(value) { return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;"); }
function makeExample(channel, url) {
    const lines = [`curl -G '${url}'`, `  --data-urlencode 'api_key=${channel.writeApiKey}'`];
    Object.entries(channel.fields || {}).forEach(([key, field]) => lines.push(`  --data-urlencode '${key}=${field.type === "state" ? "ON" : "123.4"}'`));
    return lines.join(" \\\n");
}
function setupMarkup(channel, url) {
    const example = makeExample(channel, url);
    return `<div class="card"><h2>${escapeHtml(channel.name || channel.deviceName)}</h2><p>${escapeHtml(channel.location || "Location not set")} · ${channel.isSimulated ? "Simulator channel" : "Physical sensor channel"}</p>
        <h3>HTTPS ingestion URL</h3><p class="setup-key" id="endpointText">${escapeHtml(url)}?api_key=${escapeHtml(channel.writeApiKey)}&amp;${[...Object.keys(channel.fields || {}), "created_at"].map(key => `${encodeURIComponent(key)}=...`).join("&amp;")}</p><div class="setup-actions"><button class="btn btn-secondary" id="copyEndpoint">Copy API URL</button></div>
        <h3>API write key</h3><code class="setup-key" id="writeKey">${escapeHtml(channel.writeApiKey)}</code><p class="muted">Keep this key on the device or simulator. Do not put it in public source code.</p><div class="setup-actions"><button class="btn btn-secondary" id="copyKey">Copy write key</button></div>
        <h3>Available fields</h3><ul>${Object.entries(channel.fields || {}).map(([key, field]) => `<li><strong>${escapeHtml(key)}</strong>: ${escapeHtml(field.name)} · ${escapeHtml(field.type)}${field.unit ? ` (${escapeHtml(field.unit)})` : ""}</li>`).join("")}</ul>
        <h3>Copy-paste HTTPS GET example</h3><pre class="setup-code" id="exampleCode">${escapeHtml(example)}</pre><div class="setup-actions"><button class="btn btn-secondary" id="copyExample">Copy example</button></div>
        <p class="muted">Optional <code>created_at</code> accepts an ISO timestamp or Unix epoch in seconds/milliseconds. If omitted, the ingestion server's time is used. A successful response includes the channel's incrementing <code>entry_id</code>.</p>
        <p><a href="channels.html">Back to Channels</a></p></div>`;
}

document.addEventListener("DOMContentLoaded", async () => {
    if (!channelId) { host.innerHTML = `<div class="card">Select a channel from the Channels page.</div>`; return; }
    try {
        const channel = await getChannel(channelId);
        if (!channel) { host.innerHTML = `<div class="card">Channel not found or unavailable.</div>`; return; }
        const url = getIngestionUrl();
        host.innerHTML = setupMarkup(channel, url);
        document.getElementById("copyEndpoint").addEventListener("click", async () => navigator.clipboard.writeText(`${url}?api_key=${channel.writeApiKey}`));
        document.getElementById("copyKey").addEventListener("click", async () => navigator.clipboard.writeText(channel.writeApiKey));
        document.getElementById("copyExample").addEventListener("click", async () => navigator.clipboard.writeText(document.getElementById("exampleCode").textContent));
    } catch (error) { host.innerHTML = `<div class="card">${escapeHtml(error.message)}</div>`; }
});
