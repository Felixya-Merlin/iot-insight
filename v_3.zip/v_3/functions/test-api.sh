#!/usr/bin/env bash
set -euo pipefail

API_ROOT="${1:-http://127.0.0.1:5000/api}"
WRITE_KEY="${2:?Pass the tube-light channel write key as argument 2}"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

request() {
    local expected_status="$1"
    local expected_body="$2"
    shift 2
    local status
    status="$(curl -sS -D "$TMP_DIR/headers" -o "$TMP_DIR/body" -w '%{http_code}' "$@")"
    local body
    body="$(cat "$TMP_DIR/body")"
    if [[ "$status" != "$expected_status" || "$body" != "$expected_body" ]]; then
        echo "Expected HTTP $expected_status body '$expected_body'; got HTTP $status body '$body'" >&2
        cat "$TMP_DIR/headers" >&2
        exit 1
    fi
    echo "PASS HTTP $status body=$body"
}

request 401 0 "$API_ROOT/update?api_key=bad-key&field1=25"
grep -qi '^X-Error-Code: INVALID_API_KEY' "$TMP_DIR/headers"
request 400 0 "$API_ROOT/update?api_key=$WRITE_KEY&field1=not-a-number"
grep -qi '^X-Error-Code: INVALID_NUMBER' "$TMP_DIR/headers"
request 400 0 "$API_ROOT/update?api_key=$WRITE_KEY&field1=-1"
grep -qi '^X-Error-Code: OUT_OF_RANGE' "$TMP_DIR/headers"

status="$(curl -sS -D "$TMP_DIR/headers" -o "$TMP_DIR/body" -w '%{http_code}' "$API_ROOT/update?api_key=$WRITE_KEY&field1=123.4&field2=on")"
body="$(cat "$TMP_DIR/body")"
if [[ "$status" != "200" || ! "$body" =~ ^[1-9][0-9]*$ ]]; then
    echo "Expected successful numeric entry_id; got HTTP $status body '$body'" >&2
    cat "$TMP_DIR/headers" >&2
    exit 1
fi
echo "PASS HTTP 200 entry_id=$body"
request 429 0 "$API_ROOT/update?api_key=$WRITE_KEY&field1=123.5&field2=off"
grep -qi '^X-Error-Code: RATE_LIMITED' "$TMP_DIR/headers"
