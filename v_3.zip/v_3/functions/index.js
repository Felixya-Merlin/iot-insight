const crypto = require("node:crypto");
const dns = require("node:dns").promises;
const http = require("node:http");
const https = require("node:https");
const net = require("node:net");
const admin = require("firebase-admin");
const { onRequest } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");

admin.initializeApp();
const db = admin.firestore();
class ApiError extends Error {
    constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

function updateFailure(res, error) {
    const status = error instanceof ApiError ? error.status : 500;
    const code = error instanceof ApiError ? error.code : "INTERNAL_ERROR";
    const message = error instanceof ApiError ? error.message : "Request failed.";
    res.set("X-Error-Code", code);
    res.set("X-Error-Message", encodeURIComponent(message));
    res.type("text/plain").status(status).send("0");
}

function jsonFailure(res, error) {
    const status = error instanceof ApiError ? error.status : 500;
    const code = error instanceof ApiError ? error.code : "INTERNAL_ERROR";
    const message = error instanceof ApiError ? error.message : "Request failed.";
    return res.status(status).json({ error: { code, message } });
}

function parseTimestamp(value) {
    if (value === undefined || value === null || value === "") return new Date();
    if (typeof value === "number" || /^-?\d+(\.\d+)?$/.test(String(value))) {
        const epoch = Number(value);
        const date = new Date(Math.abs(epoch) < 1e12 ? epoch * 1000 : epoch);
        return Number.isFinite(date.getTime()) ? date : null;
    }
    const date = new Date(value);
    return Number.isFinite(date.getTime()) ? date : null;
}

function normalize(field, raw) {
    if (Array.isArray(raw) || raw === undefined || raw === null || String(raw).trim() === "") {
        throw new ApiError(400, "INVALID_VALUE", `${field.fieldKey} is required and must have one value.`);
    }
    if (field.type === "state") {
        const text = String(raw).trim().toLowerCase();
        if (["1", "on", "true"].includes(text)) return { value: 1, state: "ON" };
        if (["0", "off", "false"].includes(text)) return { value: 0, state: "OFF" };
        throw new ApiError(400, "INVALID_STATE", `${field.fieldKey} accepts 1/0, on/off, or true/false.`);
    }
    const value = Number(raw);
    if (!Number.isFinite(value)) throw new ApiError(400, "INVALID_NUMBER", `${field.fieldKey} must be numeric.`);
    const minimum = field.minValue !== undefined ? Number(field.minValue) : (/lux/i.test(field.unit || "") ? 0 : null);
    if (minimum !== null && value < minimum) throw new ApiError(400, "OUT_OF_RANGE", `${field.fieldKey} must be at least ${minimum} ${field.unit || ""}.`.trim());
    return { value, state: "" };
}

function constantTimeEquals(left, right) {
    const a = Buffer.from(String(left || ""));
    const b = Buffer.from(String(right || ""));
    return a.length >= 16 && a.length === b.length && crypto.timingSafeEqual(a, b);
}

function digestApiKey(value) { return crypto.createHash("sha256").update(String(value || "")).digest("hex"); }

async function findWriteChannel(apiKey) {
    if (!apiKey || String(apiKey).length < 16) throw new ApiError(401, "INVALID_API_KEY", "A valid api_key is required.");
    const channels = await db.collection("devices").where("channelType", "==", "channel").where("writeKeyHash", "==", digestApiKey(apiKey)).limit(1).get();
    const legacyChannels = channels.empty ? await db.collection("devices").where("channelType", "==", "channel").where("writeApiKey", "==", apiKey).limit(1).get() : null;
    const channelDoc = channels.docs.find(item => constantTimeEquals(item.get("writeKeyHash"), digestApiKey(apiKey))) || legacyChannels?.docs.find(item => constantTimeEquals(item.get("writeApiKey"), apiKey));
    if (!channelDoc) throw new ApiError(401, "INVALID_API_KEY", "The write key is invalid.");
    return channelDoc;
}

function makeFeed(channel, entryId, timestamp, fieldValues) {
    return {
        entry_id: entryId,
        created_at: timestamp.toISOString(),
        ...Object.fromEntries(Object.entries(channel.fields || {}).map(([key]) => [key, fieldValues[key] ?? null]))
    };
}

function localDateParts(date, timeZone = "Asia/Kolkata") {
    const parts = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23", weekday: "short" }).formatToParts(date);
    return Object.fromEntries(parts.map(part => [part.type, part.value]));
}

function evaluateChannelAlerts(channel, feed, date) {
    const config = channel.alertSettings || {};
    if (config.enabled === false) return [];
    const timezone = config.timeZone || "Asia/Kolkata";
    const parts = localDateParts(date, timezone);
    const minuteOfDay = Number(parts.hour) * 60 + Number(parts.minute);
    const start = Number(config.labStartHour ?? 9) * 60;
    const end = Number(config.labEndHour ?? 17) * 60;
    const labHours = minuteOfDay >= start && minuteOfDay < end && !["Sat", "Sun"].includes(parts.weekday);
    const stateField = Object.values(channel.fields || {}).find(field => field.type === "state");
    const luxField = Object.values(channel.fields || {}).find(field => /lux|light/i.test(`${field.name} ${field.unit}`) && field.type !== "state");
    const alerts = [];
    const add = (key, type, severity, message, parameterName = "Tube state", value = "", threshold = "") => alerts.push({
        id: `${channel.id || channel.deviceId}_${key}`, type, severity, message, parameterName,
        value: String(value), threshold: String(threshold), timestamp: date.toISOString(), status: "open", source: "Cloud Function"
    });
    const isOn = stateField && Number(feed.values[stateField.fieldKey]?.value) === 1;
    if (isOn && luxField) {
        const lux = Number(feed.values[luxField.fieldKey]?.value);
        const threshold = Math.max(0, Number(config.dimThresholdLux ?? 200));
        if (Number.isFinite(lux) && lux < threshold) add(`dim_${parts.year}${parts.month}${parts.day}`, "Tube too dim", "warning", `Light intensity is ${lux} lux while the tube is ON.`, luxField.name, lux, `${threshold} lux`);
    }
    if (stateField && feed.values[stateField.fieldKey]) {
        if (labHours && !isOn && config.expectedOnDuringLab !== false) add(`lab_off_${parts.year}${parts.month}${parts.day}`, "Tube not ON during lab hours", "warning", "The tube is OFF during configured lab hours.", stateField.name, "OFF", "ON during lab hours");
        if (!labHours && isOn && config.expectedOffOutsideLab !== false) add(`after_hours_${parts.year}${parts.month}${parts.day}`, "Tube ON outside lab hours", "info", "The tube is ON outside configured lab hours.", stateField.name, "ON", "OFF outside lab hours");
    }
    const lux = Number(feed.values[luxField?.fieldKey]?.value);
    const stateValue = Number(feed.values[stateField?.fieldKey]?.value);
    if (Number.isFinite(lux) && luxField && (!stateField || stateValue === 1)) {
        const history = (channel.recentLux || []).slice(-12).map(Number).filter(Number.isFinite);
        if (history.length >= 5) {
            const mean = history.reduce((sum, value) => sum + value, 0) / history.length;
            const variance = history.reduce((sum, value) => sum + (value - mean) ** 2, 0) / history.length;
            const threshold = Math.max(100, Number(config.flickerVarianceThreshold ?? 10000));
            if (variance >= threshold) add(`flicker_${Math.floor(date.getTime() / 300000)}`, "Flicker detected", "warning", `Short-term light variance is high (${variance.toFixed(0)} lux²).`, luxField.name, variance.toFixed(0), `${threshold} lux²`);
        }
    }
    return alerts;
}

function updateAlertRecords(transaction, channelId, ownerUid, channel, feed, date) {
    const channelWithId = { ...channel, id: channelId };
    const newAlerts = evaluateChannelAlerts(channelWithId, feed, date);
    if (channel.alertSettings?.enabled === false) return;
    const luxField = Object.values(channel.fields || {}).find(field => /lux|light/i.test(`${field.name} ${field.unit}`) && field.type !== "state");
    const recentLux = [...(channel.recentLux || []), ...(luxField && feed.values[luxField.fieldKey] ? [Number(feed.values[luxField.fieldKey].value)] : [])].slice(-16);
    const time = admin.firestore.FieldValue.serverTimestamp();
    for (const alert of newAlerts) {
        transaction.set(db.collection("alerts").doc(alert.id), { ...alert, uid: ownerUid, channelId, deviceId: channelId, deviceName: channel.name || channel.deviceName || channelId, createdAt: time, updatedAt: time }, { merge: true });
    }
}

async function evaluateOfflineChannels() {
    const now = Date.now();
    const snapshot = await db.collection("devices").where("channelType", "==", "channel").get();
    let batch = db.batch();
    let writes = 0;
    for (const channelDoc of snapshot.docs) {
        const channel = channelDoc.data();
        if (channel.alertSettings?.enabled === false) continue;
        const lastSeen = channel.lastSeenAt?.toMillis ? channel.lastSeenAt.toMillis() : 0;
        const threshold = Math.max(1, Number(channel.offlineAfterMinutes) || 5) * 60000;
        if (!lastSeen || now - lastSeen <= threshold) {
            const staleAlert = await db.collection("alerts").doc(`${channelDoc.id}_sensor_offline`).get();
            if (staleAlert.exists && staleAlert.get("status") !== "resolved") {
                batch.set(staleAlert.ref, { status: "resolved", resolvedAt: admin.firestore.FieldValue.serverTimestamp(), updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
                writes += 1;
                if (writes === 450) { await batch.commit(); batch = db.batch(); writes = 0; }
            }
            continue;
        }
        const alertRef = db.collection("alerts").doc(`${channelDoc.id}_sensor_offline`);
        const existing = await alertRef.get();
        if (existing.exists && existing.get("status") !== "resolved") {
            batch.set(alertRef, { timestamp: new Date(now).toISOString(), value: new Date(lastSeen).toISOString(), message: `No sensor data received for ${Math.floor((now - lastSeen) / 60000)} minutes.`, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
        } else batch.set(alertRef, {
            uid: channel.ownerUid, channelId: channelDoc.id, deviceId: channelDoc.id,
            type: "Sensor offline", severity: "critical", parameterName: "Device status",
            value: new Date(lastSeen).toISOString(), threshold: `${channel.offlineAfterMinutes || 5} minutes`,
            timestamp: new Date(now).toISOString(), status: "open", source: "Cloud Function",
            message: `No sensor data received for ${Math.floor((now - lastSeen) / 60000)} minutes.`,
            createdAt: admin.firestore.FieldValue.serverTimestamp(), updatedAt: admin.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
        writes += 1;
        if (writes === 450) { await batch.commit(); batch = db.batch(); writes = 0; }
    }
    if (writes) await batch.commit();
}

function parseFeedInput(payload, channel) {
    const fields = Object.values(channel.fields || {});
    const supplied = fields.filter(field => payload[field.fieldKey] !== undefined);
    if (!supplied.length) throw new ApiError(400, "MISSING_FIELDS", "Supply at least one configured field1..field8 value.");
    const values = {};
    for (const field of supplied) values[field.fieldKey] = { ...normalize(field, payload[field.fieldKey]), rawValue: String(payload[field.fieldKey]) };
    const timestamp = parseTimestamp(payload.created_at ?? payload.timestamp);
    if (!timestamp) throw new ApiError(400, "INVALID_TIMESTAMP", "created_at must be ISO-8601 or a Unix epoch in seconds/milliseconds.");
    return { values, timestamp };
}

function requestPayload(req) {
    const body = req.method === "POST" && req.body && typeof req.body === "object" ? req.body : {};
    return { ...req.query, ...body };
}

async function storeFeeds(channelDoc, feeds) {
    const channelRef = channelDoc.ref;
        const configuredRateLimit = Number(channelDoc.get("rateLimitSeconds"));
        const rateLimitSeconds = Math.min(86400, Math.max(15, Number.isFinite(configuredRateLimit) && configuredRateLimit > 0 ? configuredRateLimit : 15));
    return db.runTransaction(async transaction => {
        const current = await transaction.get(channelRef);
        if (!current.exists) throw new ApiError(404, "CHANNEL_NOT_FOUND", "Channel no longer exists.");
        const latestUpdate = current.get("lastUpdateAt");
        const now = Date.now();
        if (latestUpdate?.toMillis && now - latestUpdate.toMillis() < rateLimitSeconds * 1000) {
            const remaining = Math.ceil(rateLimitSeconds - (now - latestUpdate.toMillis()) / 1000);
            throw new ApiError(429, "RATE_LIMITED", `Wait ${remaining} seconds before the next update.`);
        }
        let entryId = Number(current.get("entryCounter") || 0);
        const entryIds = [];
        const serverTime = admin.firestore.FieldValue.serverTimestamp();
        let alertState = { recentLux: current.get("recentLux") || [] };
        for (const feed of feeds) {
            entryId += 1;
            entryIds.push(entryId);
            updateAlertRecords(transaction, channelDoc.id, current.get("ownerUid"), { ...current.data(), ...alertState }, feed, feed.timestamp);
            const lightField = Object.values(current.get("fields") || {}).find(item => /lux|light/i.test(`${item.name} ${item.unit}`) && item.type !== "state");
            alertState = { recentLux: [...alertState.recentLux, ...(lightField && feed.values[lightField.fieldKey] ? [Number(feed.values[lightField.fieldKey].value)] : [])].slice(-16) };
            for (const [fieldKey, item] of Object.entries(feed.values)) {
                const field = (current.get("fields") || {})[fieldKey];
                const parameterId = `${channelDoc.id}_${fieldKey}`;
                const readingRef = db.collection("readings").doc(`${channelDoc.id}_${String(entryId).padStart(12, "0")}_${fieldKey}`);
                transaction.set(readingRef, {
                    uid: current.get("ownerUid"), channelId: channelDoc.id, deviceId: channelDoc.id, parameterId,
                    parameterName: field.name, fieldName: fieldKey, timestamp: feed.timestamp.toISOString(),
                    entryId, value: item.value, state: item.state, rawValue: item.rawValue,
                    source: current.get("isSimulated") ? "Simulator" : "Device", importedAt: serverTime
                });
            }
        }
        // Keep the rolling light window within the channel doc for flicker checks.
        const lastLux = feeds.map(feed => {
            const field = Object.values(current.get("fields") || {}).find(item => /lux|light/i.test(`${item.name} ${item.unit}`) && item.type !== "state");
            return field && feed.values[field.fieldKey] ? Number(feed.values[field.fieldKey].value) : null;
        }).filter(Number.isFinite);
        const recentLux = [...(current.get("recentLux") || []), ...lastLux].slice(-16);
        transaction.update(channelRef, { entryCounter: entryId, lastSeenAt: serverTime, lastUpdateAt: serverTime, updatedAt: serverTime, recentLux: alertState.recentLux.length ? alertState.recentLux : recentLux });
        return entryIds;
    });
}

async function updateRoute(req, res) {
    try {
        if (!["GET", "POST"].includes(req.method)) throw new ApiError(405, "METHOD_NOT_ALLOWED", "Use GET or POST.");
        const payload = requestPayload(req);
        const channelDoc = await findWriteChannel(payload.api_key);
        const rawFeeds = payload.feeds ?? payload.batch;
        const incomingFeeds = Array.isArray(rawFeeds) ? rawFeeds : [payload];
        if (!incomingFeeds.length || incomingFeeds.length > 60) throw new ApiError(400, "INVALID_BATCH", "Batch must contain 1 to 60 feeds.");
        const rootTimestamp = payload.created_at ?? payload.timestamp;
        const feeds = incomingFeeds.map(feed => parseFeedInput({ ...feed, created_at: feed.created_at ?? rootTimestamp }, channelDoc.data()));
        const entryIds = await storeFeeds(channelDoc, feeds);
        res.set("X-Entry-Ids", entryIds.join(","));
        return res.type("text/plain").status(200).send(String(entryIds[entryIds.length - 1]));
    } catch (error) {
        if (!(error instanceof ApiError)) console.error("Channel update failed", error);
        return updateFailure(res, error);
    }
}

async function authorizeRead(channelId, apiKey) {
    const channelDoc = await db.collection("devices").doc(channelId).get();
    if (!channelDoc.exists || channelDoc.get("channelType") !== "channel") throw new ApiError(404, "CHANNEL_NOT_FOUND", "Channel not found.");
    const channel = channelDoc.data();
    if (!channel.isPublic) {
        const secretDoc = await db.collection("channelSecrets").doc(channelId).get();
        const validHash = channel.readKeyHash ? constantTimeEquals(channel.readKeyHash, digestApiKey(apiKey)) : false;
        const legacyMatch = (secretDoc.exists && constantTimeEquals(secretDoc.get("readApiKey"), apiKey)) || constantTimeEquals(channel.readApiKey, apiKey);
        if (!validHash && !legacyMatch) throw new ApiError(401, "INVALID_READ_KEY", "A valid read api_key is required for this private channel.");
    }
    return { channelDoc, channel };
}

function publicChannel(channelDoc, channel) {
    const createdAt = channel.createdAt?.toDate ? channel.createdAt.toDate().toISOString() : null;
    const updatedAt = channel.lastSeenAt?.toDate ? channel.lastSeenAt.toDate().toISOString() : null;
    return {
        id: channelDoc.id, name: channel.name || channel.deviceName || "", description: channel.description || "",
        location: channel.location || "", public: Boolean(channel.isPublic), created_at: createdAt,
        updated_at: updatedAt, last_entry_id: Number(channel.entryCounter || 0),
        ...Object.fromEntries(Object.entries(channel.fields || {}).map(([key, field]) => [key, field.name]))
    };
}

function parseResults(value) {
    const number = Number(value || 100);
    if (!Number.isInteger(number) || number < 1) throw new ApiError(400, "INVALID_RESULTS", "results must be an integer from 1 to 8000.");
    return Math.min(number, 8000);
}

async function readFeedsRoute(req, res, channelId, format) {
    try {
        if (req.method !== "GET") throw new ApiError(405, "METHOD_NOT_ALLOWED", "Use GET.");
        const { channelDoc, channel } = await authorizeRead(channelId, req.query.api_key);
        const results = parseResults(req.query.results);
        const start = req.query.start ? parseTimestamp(req.query.start) : null;
        const end = req.query.end ? parseTimestamp(req.query.end) : null;
        if ((req.query.start && !start) || (req.query.end && !end)) throw new ApiError(400, "INVALID_RANGE", "start and end must be ISO-8601 or Unix timestamps.");
        let readingQuery = db.collection("readings").where("channelId", "==", channelDoc.id);
        if (start) readingQuery = readingQuery.where("timestamp", ">=", start.toISOString());
        if (end) readingQuery = readingQuery.where("timestamp", "<=", end.toISOString());
        const snapshot = await readingQuery.orderBy("timestamp", "desc").limit(results * 8).get();
        const feeds = new Map();
        snapshot.docs.forEach(document => {
            const item = document.data();
            const timestamp = parseTimestamp(item.timestamp);
            if (!timestamp || (start && timestamp < start) || (end && timestamp > end)) return;
            const key = String(item.entryId);
            if (!feeds.has(key)) feeds.set(key, { timestamp, fields: {} });
            feeds.get(key).fields[item.fieldName] = item.value;
        });
        const entries = [...feeds.entries()].map(([entryId, item]) => makeFeed(channel, Number(entryId), item.timestamp, item.fields))
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, results).reverse();
        if (format === "csv") {
            const fieldKeys = Object.keys(channel.fields || {});
            const rows = [["created_at", "entry_id", ...fieldKeys], ...entries.map(feed => [feed.created_at, feed.entry_id, ...fieldKeys.map(key => feed[key] ?? "")])];
            return res.type("text/csv").status(200).send(rows.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n"));
        }
        return res.status(200).json({ channel: publicChannel(channelDoc, channel), feeds: entries });
    } catch (error) { return jsonFailure(res, error); }
}

async function fieldRoute(req, res, channelId, fieldNumber, format) {
    try {
        if (req.method !== "GET") throw new ApiError(405, "METHOD_NOT_ALLOWED", "Use GET.");
        const { channelDoc, channel } = await authorizeRead(channelId, req.query.api_key);
        const key = `field${fieldNumber}`;
        const field = channel.fields?.[key];
        if (!field) throw new ApiError(404, "FIELD_NOT_FOUND", `Channel has no ${key}.`);
        if (format === "csv") {
            const snapshot = await db.collection("readings").where("channelId", "==", channelDoc.id).where("fieldName", "==", key).orderBy("timestamp", "desc").limit(8000).get();
            const rows = [["created_at", "entry_id", key], ...snapshot.docs.slice().reverse().map(item => { const value = item.data(); return [value.timestamp, value.entryId, value.value]; })];
            return res.type("text/csv").status(200).send(rows.map(row => row.map(value => `"${String(value ?? "").replaceAll('"', '""')}"`).join(",")).join("\r\n"));
        }
        return res.status(200).json({ channel: publicChannel(channelDoc, channel), field: { field: field.name, unit: field.unit || "", type: field.type } });
    } catch (error) { return jsonFailure(res, error); }
}

function isPublicIp(address) {
    const family = net.isIP(address);
    if (family === 4) {
        const octets = address.split(".").map(Number);
        const [a, b, c] = octets;
        const inRange = (base, prefix) => {
            const bits = prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0;
            const value = (((a << 24) >>> 0) | (b << 16) | (c << 8) | octets[3]) >>> 0;
            return (value & bits) === (base & bits);
        };
        const blocked = ["0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8", "169.254.0.0/16", "172.16.0.0/12", "192.0.0.0/24", "192.0.2.0/24", "192.88.99.0/24", "192.168.0.0/16", "198.18.0.0/15", "198.51.100.0/24", "203.0.113.0/24", "224.0.0.0/4", "240.0.0.0/4"];
        return !blocked.some(item => {
            const [network, prefix] = item.split("/");
            const base = network.split(".").map(Number).reduce((value, octet) => ((value << 8) | octet) >>> 0, 0);
            return inRange(base, Number(prefix));
        });
    }
    if (family !== 6) return false;
    const normalized = address.toLowerCase().split("%")[0];
    if (normalized.startsWith("::ffff:")) return isPublicIp(normalized.slice(7));
    const firstGroup = parseInt(normalized.split(":")[0] || "0", 16);
    return firstGroup >= 0x2000 && firstGroup <= 0x3fff &&
        !normalized.startsWith("2001:db8:") && !normalized.startsWith("2001:0000:") && !normalized.startsWith("2002:");
}

async function resolvePublicAddress(url) {
    const hostname = url.hostname.replace(/^\[|\]$/g, "").toLowerCase();
    if (!hostname || hostname === "localhost" || hostname.endsWith(".localhost") || hostname.endsWith(".local") || hostname.endsWith(".internal")) {
        throw new ApiError(400, "BLOCKED_HOST", "Local and internal hostnames are not allowed.");
    }
    if (url.username || url.password || (url.protocol === "https:" && url.port && url.port !== "443") || (url.protocol === "http:" && url.port && url.port !== "80")) {
        throw new ApiError(400, "BLOCKED_URL", "Credentials and nonstandard ports are not allowed.");
    }
    const literalFamily = net.isIP(hostname);
    let addresses;
    try { addresses = literalFamily ? [{ address: hostname, family: literalFamily }] : await dns.lookup(hostname, { all: true, verbatim: true }); }
    catch { throw new ApiError(400, "DNS_FAILED", "The source host could not be resolved."); }
    if (!addresses.length || addresses.some(item => !isPublicIp(item.address))) {
        throw new ApiError(400, "BLOCKED_HOST", "The source host resolves to a private or reserved network address.");
    }
    return addresses[0];
}

async function requestPublicFeed(rawUrl, redirects = 0) {
    if (redirects > 3) throw new ApiError(502, "TOO_MANY_REDIRECTS", "The source URL redirected too many times.");
    let url;
    try { url = new URL(rawUrl); } catch { throw new ApiError(400, "INVALID_URL", "Provide a valid absolute HTTP or HTTPS URL."); }
    if (!['http:', 'https:'].includes(url.protocol)) throw new ApiError(400, "INVALID_URL", "Only HTTP and HTTPS source URLs are supported.");
    const address = await resolvePublicAddress(url);
    const client = url.protocol === "https:" ? https : http;
    return new Promise((resolve, reject) => {
        const request = client.get(url, {
            headers: { Accept: "application/json, text/csv, text/plain, application/*+json", "User-Agent": "IoT-Insight-URL-Import/1.0" },
            lookup: (_hostname, _options, callback) => callback(null, address.address, address.family)
        }, response => {
            const status = response.statusCode || 502;
            if ([301, 302, 303, 307, 308].includes(status) && response.headers.location) {
                response.resume();
                requestPublicFeed(new URL(response.headers.location, url).toString(), redirects + 1).then(resolve, reject);
                return;
            }
            if (status < 200 || status >= 300) {
                response.resume();
                reject(new ApiError(502, "SOURCE_HTTP_ERROR", `Source returned HTTP ${status}.`));
                return;
            }
            const contentType = String(response.headers["content-type"] || "").split(";")[0].trim().toLowerCase();
            if (!(contentType === "application/json" || contentType.endsWith("+json") || contentType === "text/csv" || contentType === "text/plain")) {
                response.resume();
                reject(new ApiError(415, "UNSUPPORTED_SOURCE_TYPE", "Source must return JSON or CSV text."));
                return;
            }
            const chunks = [];
            let totalBytes = 0;
            response.on("data", chunk => {
                totalBytes += chunk.length;
                if (totalBytes > 2 * 1024 * 1024) request.destroy(new ApiError(413, "SOURCE_TOO_LARGE", "Source response exceeds the 2 MB limit."));
                else chunks.push(chunk);
            });
            response.on("end", () => resolve({ text: Buffer.concat(chunks).toString("utf8"), contentType }));
            response.on("error", reject);
        });
        request.setTimeout(10000, () => request.destroy(new ApiError(504, "SOURCE_TIMEOUT", "Source request timed out.")));
        request.on("error", reject);
    });
}

async function importProxyRoute(req, res) {
    try {
        if (req.method !== "POST") throw new ApiError(405, "METHOD_NOT_ALLOWED", "Use POST.");
        const authorization = String(req.get("Authorization") || "");
        const match = authorization.match(/^Bearer\s+(.+)$/i);
        if (!match) throw new ApiError(401, "AUTH_REQUIRED", "A signed-in Firebase user is required.");
        try { await admin.auth().verifyIdToken(match[1]); }
        catch { throw new ApiError(401, "AUTH_REQUIRED", "The Firebase user token is invalid or expired."); }
        if (typeof req.body?.url !== "string" || req.body.url.length > 2048) throw new ApiError(400, "INVALID_URL", "Provide a source URL no longer than 2048 characters.");
        const result = await requestPublicFeed(req.body.url);
        return res.set("Cache-Control", "no-store").status(200).json(result);
    } catch (error) { return jsonFailure(res, error); }
}

async function authenticatedUid(req) {
    const match = String(req.get("Authorization") || "").match(/^Bearer\s+(.+)$/i);
    if (!match) throw new ApiError(401, "AUTH_REQUIRED", "A signed-in Firebase user is required.");
    try { return (await admin.auth().verifyIdToken(match[1])).uid; }
    catch { throw new ApiError(401, "AUTH_REQUIRED", "The Firebase user token is invalid or expired."); }
}

async function importReadingsRoute(req, res) {
    try {
        if (req.method !== "POST") throw new ApiError(405, "METHOD_NOT_ALLOWED", "Use POST.");
        const uid = await authenticatedUid(req);
        const { channelId, feeds, source = "Import", sourceUrl = "" } = req.body || {};
        if (typeof channelId !== "string" || !Array.isArray(feeds) || feeds.length > 60) throw new ApiError(400, "INVALID_IMPORT", "Provide a channelId and 1 to 60 feeds per request.");
        const channelRef = db.collection("devices").doc(channelId);
        const channelDoc = await channelRef.get();
        if (!channelDoc.exists || channelDoc.get("ownerUid") !== uid || channelDoc.get("channelType") !== "channel") throw new ApiError(403, "CHANNEL_FORBIDDEN", "The channel is not owned by this account.");
        const channel = channelDoc.data();
        const configuredFields = channel.fields || {};
        let saved = 0;
        for (let offset = 0; offset < feeds.length; offset += 60) {
            const chunk = feeds.slice(offset, offset + 60).map((feed, index) => {
                const timestamp = parseTimestamp(feed.timestamp);
                if (!timestamp || !feed.values || typeof feed.values !== "object") throw new ApiError(400, "INVALID_IMPORT_ROW", `Import row ${offset + index + 1} is malformed.`);
                const values = {};
                for (const [fieldKey, item] of Object.entries(feed.values)) {
                    const field = configuredFields[fieldKey];
                    if (!field) continue;
                    const raw = item?.rawValue ?? item?.value;
                    values[fieldKey] = { ...normalize(field, raw), rawValue: String(raw) };
                }
                const sourceId = String(feed.sourceEntryId || `${timestamp.toISOString()}_${offset + index}`);
                return { timestamp, values, sourceId };
            }).filter(feed => Object.keys(feed.values).length);
            if (!chunk.length) continue;
            saved += await db.runTransaction(async transaction => {
                const current = await transaction.get(channelRef);
                if (!current.exists || current.get("ownerUid") !== uid) throw new ApiError(403, "CHANNEL_FORBIDDEN", "The channel is no longer available.");
                const plans = chunk.map(feed => {
                    const entryHash = crypto.createHash("sha256").update(`${sourceUrl}:${feed.sourceId}`).digest("hex").slice(0, 24);
                    const fields = Object.entries(feed.values);
                    const refs = fields.map(([fieldKey]) => db.collection("readings").doc(`${channelId}_import_${entryHash}_${fieldKey}`));
                    return { feed, fields, refs };
                });
                const existing = await Promise.all(plans.flatMap(plan => plan.refs.map(ref => transaction.get(ref))));
                let cursor = 0; let entryCounter = Number(current.get("entryCounter") || 0); let inserted = 0;
                const serverTime = admin.firestore.FieldValue.serverTimestamp();
                for (const plan of plans) {
                    const snaps = existing.slice(cursor, cursor + plan.refs.length); cursor += plan.refs.length;
                    const oldEntryId = snaps.find(snapshot => snapshot.exists)?.get("entryId");
                    const entryId = oldEntryId || ++entryCounter;
                    plan.fields.forEach(([fieldKey, item], index) => {
                        if (snaps[index].exists) return;
                        const field = configuredFields[fieldKey];
                        transaction.create(plan.refs[index], { uid, channelId, deviceId: channelId, parameterId: `${channelId}_${fieldKey}`, parameterName: field.name, fieldName: fieldKey, timestamp: plan.feed.timestamp.toISOString(), entryId, value: item.value, state: item.state || "", rawValue: item.rawValue, source, sourceUrl, sourceEntryId: plan.feed.sourceId, importedAt: serverTime });
                    });
                    if (!oldEntryId) inserted += 1;
                }
                if (inserted) transaction.update(channelRef, { entryCounter, updatedAt: serverTime });
                return inserted;
            });
        }
        return res.status(200).json({ saved });
    } catch (error) { return jsonFailure(res, error); }
}

async function deleteChannelDataRoute(req, res) {
    try {
        if (req.method !== "POST") throw new ApiError(405, "METHOD_NOT_ALLOWED", "Use POST.");
        const uid = await authenticatedUid(req);
        const channelId = String(req.body?.channelId || "");
        if (!channelId) throw new ApiError(400, "CHANNEL_REQUIRED", "Provide a channelId.");
        const channel = await db.collection("devices").doc(channelId).get();
        if (!channel.exists || channel.get("ownerUid") !== uid) throw new ApiError(403, "CHANNEL_FORBIDDEN", "The channel is not owned by this account.");
        const readings = await db.collection("readings").where("channelId", "==", channelId).get();
        for (let offset = 0; offset < readings.docs.length; offset += 450) {
            const batch = db.batch(); readings.docs.slice(offset, offset + 450).forEach(snapshot => batch.delete(snapshot.ref)); await batch.commit();
        }
        const alerts = await db.collection("alerts").where("channelId", "==", channelId).get();
        for (let offset = 0; offset < alerts.docs.length; offset += 450) {
            const batch = db.batch(); alerts.docs.slice(offset, offset + 450).forEach(snapshot => batch.delete(snapshot.ref)); await batch.commit();
        }
        return res.status(200).json({ deleted: readings.size, alertsDeleted: alerts.size });
    } catch (error) { return jsonFailure(res, error); }
}

exports.api = onRequest({ region: "us-central1", cors: true }, async (req, res) => {
    res.set("Access-Control-Allow-Origin", "*");
    res.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    res.set("Access-Control-Expose-Headers", "X-Error-Code, X-Error-Message, X-Entry-Ids");
    if (req.method === "OPTIONS") return res.status(204).send("");
    const path = req.path.replace(/\/+$/, "") || "/";
    if (path === "/api/update" || path === "/update") return updateRoute(req, res);
    if (path === "/api/import-proxy" || path === "/import-proxy") return importProxyRoute(req, res);
    if (path === "/api/import-readings" || path === "/import-readings") return importReadingsRoute(req, res);
    if (path === "/api/delete-channel-data" || path === "/delete-channel-data") return deleteChannelDataRoute(req, res);
    let match = path.match(/^\/api\/channels\/([^/]+)\/feeds\.(json|csv)$/) || path.match(/^\/channels\/([^/]+)\/feeds\.(json|csv)$/);
    if (match) return readFeedsRoute(req, res, decodeURIComponent(match[1]), match[2]);
    match = path.match(/^\/api\/channels\/([^/]+)\/fields\/([1-8])\.(json|csv)$/) || path.match(/^\/channels\/([^/]+)\/fields\/([1-8])\.(json|csv)$/);
    if (match) return fieldRoute(req, res, decodeURIComponent(match[1]), match[2], match[3]);
    return jsonFailure(res, new ApiError(404, "NOT_FOUND", "API route not found."));
});

exports.checkOfflineChannels = onSchedule({ schedule: "every 5 minutes", timeZone: "Asia/Kolkata", region: "us-central1" }, async () => {
    await evaluateOfflineChannels();
});
