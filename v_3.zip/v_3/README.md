﻿# IoT Insight

IoT Insight is a static vanilla HTML/CSS/JavaScript application using Firebase Authentication, Firestore, optional Realtime Database, and Node.js 20 Firebase Cloud Functions (2nd gen). Chart.js renders channel telemetry. Cloud Functions provide the ESP32 ingestion/read API, authenticated imports, and scheduled offline alerts. Firebase Hosting serves the app and rewrites `/api/**` to the API function.

## Architecture

- Vanilla HTML/CSS/JavaScript remains the frontend stack.
- Firebase Firestore is the database.
- Firebase Authentication provides the signed-in identity required by Firestore rules and app APIs.
- Sensors send only `field1` through `field8`; channel field names/types live in Firestore.
- ThingSpeak JSON/CSV and local CSV sources can be imported into an existing channel.
- `tools/simulator.js` sends the same HTTPS GET shape as the ESP32.
- Channel and imported readings reuse `devices`, `parameters`, `readings`, and `imports`.

## 1. Create Firebase project

1. Open Firebase Console.
2. Create a project named `iot-insight` (or another name).
3. Add a Web App.
4. Copy the Firebase web configuration.
5. Copy `js/firebase-config.example.js` to `js/firebase-config.local.js` and paste your Firebase Web App values there. This file is Git-ignored, but Firebase Hosting must deploy it because the browser loads it at runtime.
6. In Authentication -> Sign-in method, enable **Email/Password**.
7. In Firestore Database, create the database.
8. Deploy the production rules in `firestore.rules` (and `database.rules.json` if Realtime Database is enabled).

The Firebase Web App `apiKey` is a public project identifier, not a service credential; static web apps must send it to the browser. Restrict it in Google Cloud Console to the required Firebase APIs and your production HTTP referrers. Never put Firebase Admin service-account keys, private keys, passwords, or channel write keys in source code. This repository ignores local service-account and environment-secret files.

## Deploy to Firebase Hosting

This repository is already initialized: `firebase.json` configures Hosting at
the project root and rewrites `/api/**` to the 2nd gen function. Avoid rerunning
`firebase init` on this checkout because Firebase CLI reinitialization can
replace the existing Hosting rewrite. From the repository root, install and
authenticate the CLI, link the existing project, and deploy:

```text
npm install -g firebase-tools
firebase login
firebase projects:list
firebase use --add
npm install --prefix functions
firebase deploy --project iot-insight
```

For `firebase use --add`, select the existing `iot-insight` project and assign
an alias such as `default`. The deploy publishes Hosting, the API function,
Firestore rules, and indexes from the existing configuration. If initializing a
fresh checkout instead, use `firebase init hosting,functions --project iot-insight`, select JavaScript/Node.js 20, Hosting public directory `.`, and
answer **No** to the single-page-app rewrite. Preserve the existing `firebase.json`
API rewrite and do not overwrite `functions/index.js` or `index.html`.

Cloud Functions require the Blaze plan and a linked billing account. Create an
alerts budget in Google Cloud Console > Billing > Budgets & alerts; scope it to
this project, set a monthly amount, enable email alerts (for example 50%, 90%,
and 100%), and consider a Cloud Functions spend cap. Alerts alone do not stop
charges. Check current Firebase and Google Cloud pricing pages for included
usage and rates before deployment; usage outside current no-cost allowances
can cost money.

After deploying the site, Firebase Hosting's default URLs use the project ID:
`https://iot-insight.web.app` and `https://iot-insight.firebaseapp.com`.
In Firebase Console > Authentication > Settings > Authorized domains, add
`iot-insight.web.app`; keep `iot-insight.firebaseapp.com` and add your custom
domain after connecting it in Hosting.
Firebase Hosting > Add custom domain walks through ownership TXT and DNS A/AAAA
records, then automatically provisions and renews SSL. Use the exact records
shown by that wizard and keep its verification TXT record in DNS. Check current
student developer offers before buying a domain; promotional terms and renewal
prices can change.

## 2. Collect ThingSpeak data manually

For the first Smart Bulb/LED-state demonstration, use a public channel such as:

https://thingspeak.mathworks.com/channels/1079740

The public channel exposes a field named `Led State`.

From the ThingSpeak channel page:

1. Open the channel.
2. Use the channel's CSV export link.
3. Save the CSV file on your computer.
4. Open `pages/data-import.html` in IoT Insight.
5. Select the CSV.
6. Select the state field.
7. Keep `Power State` as the application parameter name.
8. Preview the rows.
9. Click **Import to Firebase**.

## 3. Data model

### devices/{deviceId}

- deviceId
- deviceName
- location
- source
- sourceChannelId
- sourceUrl
- updatedAt

### parameters/{parameterId}

- parameterId
- deviceId
- parameterName
- unit
- fieldName
- sourceChannelId
- updatedAt

### readings/{autoId}

- deviceId
- parameterId
- parameterName
- timestamp
- entryId
- value
- state
- rawValue
- source
- sourceChannelId
- importedAt

### imports/{autoId}

- deviceId
- parameterId
- source
- sourceChannelId
- sourceUrl
- readingCount
- importedAt

## 4. Local run

Because ES modules and Firebase work more reliably through a local web server, use VS Code Live Server or another static server.

Example:

```text
Open the project folder in VS Code
Right-click index.html
Choose "Open with Live Server"
```

Then open:

```text
pages/data-import.html
```

## Live monitoring, URL feeds, and public embeds

Dashboard and Device Details subscribe to the signed-in user's Firestore
readings and channel records. The UI derives ONLINE/OFFLINE from each channel's
`lastSeenAt` and `offlineAfterMinutes`, and displays a latest-value gauge.

On **Data Import**, use **Connect via API URL** to fetch ThingSpeak
`feeds.json`, a generic JSON array, or CSV. Review the detected format, map
source columns to the selected channel's fields, then save. Optional automatic
refresh is limited to 15 or 30 seconds. Cross-origin failures use the
authenticated `/api/import-proxy` function, which permits only HTTP(S), limits
response size and redirects, resolves/pins public IPs, and rejects private or
reserved destinations. Deploying this proxy requires Firebase Blaze because it
runs as a Cloud Function.

Public channels can be embedded with `/embed.html?channel=CHANNEL_ID&field=1`.
Private channels require a read key and therefore cannot be displayed on the
public embed page. The embed uses the same time-series chart controls as the
app.

### Step 6 local test

Start the Auth, Firestore, Functions, and Hosting emulators as shown above. Sign
in and create a channel, then open **Data Import** and paste a public ThingSpeak
feed URL such as `https://api.thingspeak.com/channels/1079740/feeds.json?results=10`.
Review field mapping/preview and save. Turn on automatic refresh to check for
new feed rows at 15 or 30 seconds. For cross-origin proxy testing, use an
authenticated session; a URL resolving to localhost/private IP (such as
`http://127.0.0.1/feeds.json`) should be rejected by the proxy.

For live sensor display, create a simulated channel, start `tools/simulator.js`
against `http://127.0.0.1:5000`, and leave Dashboard or its Device Details page
open. New readings should appear without reloading. Stop the simulator and
wait longer than that channel's offline threshold to see OFFLINE. To check
embedding, mark a channel public and open
`http://127.0.0.1:5000/embed.html?channel=CHANNEL_ID&field=1`; the iframe form
is shown on the page. A private channel should be denied.

## Step 7: Alerts, insights, and persisted workspace settings

Channel alert rules run inside the Cloud Function transaction that stores each
API reading. Configure light threshold, lab hours/timezone, expected tube state,
and flicker variance from **Channels > Alert thresholds and lab hours**. Alert
records live in `alerts/{channelId_rule_period}` with `open`, `acknowledged`,
or `resolved` status and can be acknowledged/resolved on Alerts. The offline
checker runs every five minutes and uses each channel's `offlineAfterMinutes`;
the alert can therefore be raised up to five minutes after that threshold.
Scheduled Functions require Blaze. Deployment now includes the
`checkOfflineChannels` scheduled function.

Insights reports numeric min/max/average/median, standard deviation, linear
trend, z-score outliers, tube ON duration/switches, ON-period average light,
estimated brightness change, energy and tariff estimate, and outside-lab ON
percentage. Energy defaults are configurable per channel. These are estimates
based on the stored state/light samples and configured wattage/tariff.

Settings and active-channel selection are stored in `users/{uid}`. Saved
insights are stored under `users/{uid}/reports/insights`. The Parameters modal
adds or edits channel field definitions and persists them to the existing
`devices` and `parameters` collections. Firestore rules now cover users,
reports, and alerts; deploy the updated rules before trying those features:

```text
firebase deploy --only firestore:rules,functions --project iot-insight
```

### Step 7 local test

Start the Auth, Firestore, Functions, and Hosting emulators. Sign in, create a
channel with Light intensity (lux) and Tube state fields, and set a low dim
threshold (for example 400 lux). Send one update with `field1=100&field2=on`;
check for an open **Tube too dim** alert in Alerts and Dashboard. Send state OFF
during configured weekday lab hours and ON outside hours to check those alert
types. For flicker, set a low variance threshold and send at least six varying
ON lux readings (respect the channel's 15-second rate minimum). Acknowledge and
resolve alerts from the Alerts page.

Set the channel offline threshold to one minute, stop the simulator, and wait
for the five-minute scheduled check; the emulator may not execute scheduled
functions automatically, so deploy to a Blaze project or use the Functions
emulator's scheduled trigger support to verify offline creation. Check Insights
against known sample values, change wattage/tariff, and add an insight to a
report. Change active channel in Settings or Dashboard, reload, and confirm it
persists. Edit/add a channel field from Parameters, reload, and confirm the
channel schema changed in Channels.

## Optional live temperature telemetry

The dashboard can also subscribe to Firebase Realtime Database at the signed-in
user's `sensors/temperature/{uid}` path. To enable it:

1. Create/enable Realtime Database for the Firebase project.
2. Copy its exact database URL into `databaseURL` in `js/firebase-config.js`.
3. Keep database access restricted to authenticated clients with suitable
   Firebase security rules; do not enable global public read/write access.
4. Write telemetry records under `sensors/temperature/{uid}/{recordId}` with numeric `value` and `time`
   properties. `time` may be a Unix timestamp in seconds/milliseconds or a
   date string. The dashboard displays the latest 15 valid readings.

The listener uses the signed-in Firebase user and reports connection or
permission errors in the dashboard. If no Realtime Database URL is configured,
the existing Firestore/ThingSpeak CSV dashboard remains available.

## Channels and device ingestion

Channels reuse the existing Firestore collections: channel configuration lives in
`devices/{channelId}`, field metadata lives in `parameters/{channelId_fieldN}`,
and telemetry lives in `readings`. CSV imports also create a channel record
and preserve all CSV columns as parameters; the API configuration uses up to
the first eight fields.

The Node.js 20, 2nd gen function in `functions/index.js` serves the update and
read API. Firebase Hosting rewrites `/api/**` to it. Deploy the API, Hosting
rewrite, indexes, and production rules with the Firebase CLI:

```text
firebase deploy --only functions,hosting,firestore:rules,database --project iot-insight
```

Cloud Functions deployment requires the Firebase Blaze plan and a linked billing
account. Check current included usage and rates before deployment; usage beyond
no-cost allowances and other services may be billed. Set a budget alert before
deployment. See [Firebase pricing plans](https://firebase.google.com/docs/projects/billing/firebase-pricing-plans)
and [Firebase pricing](https://firebase.google.com/pricing).

After deployment, open **Channels**, create a channel, then choose **Device
setup** to copy its HTTPS endpoint and GET example. Updates accept GET or POST;
success is a plain numeric `entry_id`, and failures return plain `0` with an
HTTP status plus `X-Error-Code` / `X-Error-Message` headers. Batch POSTs accept
up to 60 feeds. A channel's configurable rate interval cannot be less than 15
seconds. `offlineAfterMinutes` derives its ONLINE/OFFLINE state from
`lastSeenAt`. `X-Error-Message` is URL-encoded for safe use in an HTTP header.

### Local Emulator Suite test

Install Firebase CLI and Java JDK 21+, install the function dependencies with
`npm install` in `functions/`, then from the project root run:

```text
firebase emulators:start --only auth,firestore,functions,hosting --project iot-insight
```

Open `http://127.0.0.1:5000/?emulator=1`, create/sign into a test account, and
create a private tube-light channel. The `emulator=1` setting connects browser
Auth and Firestore to the local emulators. Copy the channel ID and write key.
In Git Bash, run the assertion script (it checks invalid key, numeric value,
negative lux, successful entry ID, and an immediate rate-limit rejection):

```text
bash functions/test-api.sh http://127.0.0.1:5000/api WRITE_KEY
```

A direct GET test is:

```text
curl -i "http://127.0.0.1:5000/api/update?api_key=WRITE_KEY&field1=123.4&field2=on"
```

POST and batch example:

```text
curl -i -X POST "http://127.0.0.1:5000/api/update" -H "Content-Type: application/json" -d '{"api_key":"WRITE_KEY","feeds":[{"field1":123.4,"field2":"on"},{"created_at":"2025-01-01T00:00:00Z","field1":121.8,"field2":"off"}]}'
```

Expected success is HTTP 200 with a plain numeric body. Immediately repeat it:
expected HTTP 429, body `0`, and `X-Error-Code: RATE_LIMITED`. Test private reads
with `GET /api/channels/CHANNEL_ID/feeds.json?results=20&api_key=READ_KEY`;
public channels may be read without the key. `/feeds.csv` and
`/fields/1.json` or `.csv` use the same visibility check.

### Sensor simulator

Use Node.js 18+ to run the ESP32-style live GET simulator. First create a
channel in **Channels** with **Simulated channel** enabled, then copy its write
key. Point `--host` at the local Hosting emulator or deployed site:

```text
node tools/simulator.js --host http://127.0.0.1:5000 --key WRITE_KEY
```

Live updates are GET requests to `/api/update` and the default interval is 20
seconds (minimum 15 seconds, matching the API rate limit). Stop with Ctrl+C.
Use `--scenario normal|dimming|flicker|failure|always-on`; for example:

```text
node tools/simulator.js --host http://127.0.0.1:5000 --key WRITE_KEY --scenario flicker --interval 20
```

To populate history first, add `--backfill 7` for seven days of 15-minute
samples. Backfill uses the API's supported POST batch mode (up to 60 samples per
request) and waits one configured interval between batches; live simulator
requests continue to use the ESP32-compatible GET format. Set `--interval` at
least as high as the channel's configured rate limit. Marked channels show a
**SIMULATED** badge in Channels, Dashboard, and Reports.

## Step 9: Security and final setup

### Architecture and collections

- `devices/{channelId}` stores channel metadata, public flag, field definitions,
  key digests (not API keys), last-seen time, and channel settings.
- `channelSecrets/{channelId}` stores write/read API keys. Firestore rules allow
  only the channel owner to read these documents.
- `parameters/{channelId_fieldN}` stores field definitions and units.
- `readings/{readingId}` stores telemetry. Client Firestore writes are denied;
  sensor updates, authenticated CSV/URL imports, and channel-reading deletion
  run through Cloud Functions using the Admin SDK.
- `alerts/{alertId}` stores per-channel alerts. Functions create alerts; the
  owner can update only status and status timestamps.
- `users/{uid}` and its `reports` subcollection store preferences and saved
  report insights.
- Optional RTDB samples are user scoped at
  `sensors/temperature/{uid}/{recordId}`.

Production rules are in `firestore.rules` and `database.rules.json`:

```text
firebase deploy --only firestore:rules,database --project iot-insight
```

Public channels expose metadata, configured fields, and readings. Private
channels are owner-only in Firestore and require their read key through the
Cloud API. API keys are stored in `channelSecrets` and cannot be read by other
users. The owner UI migrates older channel documents by moving legacy plaintext
keys to `channelSecrets` and replacing them with SHA-256 digests. Legacy public
channel documents containing old key fields are denied public Firestore reads
until their owner opens Channels and migration runs. The API accepts legacy
keys during that migration window.

### Channel API

The public ESP32-compatible route is `GET /api/update` (POST and up to 60-feed
batch POST are also supported):

```text
GET /api/update?api_key=WRITE_KEY&field1=350.2&field2=ON&created_at=2026-10-06T09%3A00%3A00Z
```

Success returns a plain numeric `entry_id`; errors return plain `0`, HTTP status,
and `X-Error-Code` / URL-encoded `X-Error-Message` headers. The channel rate
limit has a 15-second minimum. Numeric/state validation follows channel field
definitions. Read endpoints:

```text
GET /api/channels/CHANNEL_ID/feeds.json?results=100&api_key=READ_KEY
GET /api/channels/CHANNEL_ID/feeds.csv?start=2026-10-01T00%3A00%3A00Z&end=2026-10-06T23%3A59%3A59Z&api_key=READ_KEY
GET /api/channels/CHANNEL_ID/fields/1.json?results=100&api_key=READ_KEY
```

Public feed reads do not require a key. Private feeds require the read key.
`/api/import-readings` and `/api/delete-channel-data` require a signed-in Firebase
ID token and are app workflows, not sensor routes. `/api/import-proxy` fetches
external URLs with HTTP(S), public-IP, redirect, timeout, and response-size
restrictions.

### ESP32 HTTPS example

Use Device setup to copy the channel endpoint and write key. Keep the write key
on the device and out of source control. Install the current root CA for your
deployed Hosting domain; do not use `setInsecure()` in production.

```cpp
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>

const char* host = "iot-insight.web.app";
const char* writeKey = "PASTE_CHANNEL_WRITE_KEY";
const char* rootCa = "-----BEGIN CERTIFICATE-----\nPASTE_CURRENT_ROOT_CA\n-----END CERTIFICATE-----\n";

void sendReading(float lux, bool tubeOn) {
  WiFiClientSecure tls;
  tls.setCACert(rootCa);
  HTTPClient http;
  String url = String("https://") + host + "/api/update?api_key=" + writeKey +
    "&field1=" + String(lux, 1) + "&field2=" + (tubeOn ? "ON" : "OFF");
  if (http.begin(tls, url)) {
    int status = http.GET();
    String entryId = http.getString();
    Serial.printf("HTTP %d, entry_id %s\n", status, entryId.c_str());
    http.end();
  }
}
```

Follow Espressif's certificate bundle guidance for root CA rotation. Send
updates no more often than the channel's configured rate limit.

```text
curl -i "https://iot-insight.web.app/api/update?api_key=WRITE_KEY&field1=350.2&field2=ON"
curl -i "https://iot-insight.web.app/api/channels/CHANNEL_ID/feeds.json?results=20&api_key=READ_KEY"
```

### Setup and deploy

1. Install Node.js 20, Java 21+ for emulators, and Firebase CLI (`npm install -g firebase-tools`).
2. Copy `js/firebase-config.example.js` to ignored `js/firebase-config.local.js`, configure Web App values, and enable the desired Auth provider.
3. Create Firestore and optionally Realtime Database. RTDB records belong below `sensors/temperature/{uid}/{recordId}`.
4. Install Functions dependencies and sign in:

```text
npm install --prefix functions
firebase login
firebase use --add
```

5. Functions and scheduled offline alerts need Blaze billing. Set a Google Cloud Billing budget alert before deployment; notifications do not cap spending.
6. Deploy:

```text
firebase deploy --only hosting,functions,firestore:rules,database --project iot-insight
```

Add the Hosting domain under Firebase Authentication > Settings > Authorized
domains. For a custom domain, use the Hosting domain wizard and apply its DNS
records; Hosting provisions SSL after verification.

### Local test checklist

Start emulators:

```text
firebase emulators:start --only auth,firestore,functions,hosting,database --project iot-insight
```

- Sign in and create a private channel. Confirm raw keys are only in
  `channelSecrets/{channelId}`, with only key hashes in `devices`.
- Confirm a signed-out browser and a second account cannot read private channel
  data, secrets, readings, alerts, or user settings.
- Mark a channel public. Confirm another account can read channel metadata,
  fields, and readings, but cannot read `channelSecrets`.
- Try client Firestore create/update/delete on `readings`; all must be denied.
  Import CSV and URL feeds; both should save through authenticated Functions.
- Send valid sensor GET/curl updates. Check invalid write key, numeric text,
  negative lux, invalid state, and immediate second update (`RATE_LIMITED`).
- Trigger dim, lab-hours, flicker, and offline conditions. Acknowledge/resolve
  alerts; confirm another account cannot update them.
- Change Settings, active channel, fields, alert thresholds, and saved report
  insights. Reload and verify persistence.
- Test narrow phone and tablet widths: navigation, forms, key controls, charts,
  tables, Reports, and exports should remain usable without clipped controls.
- Export PDF, CSV, XLSX, and JSON with readings, then with an empty date range
  and a simulated channel.
- If RTDB is enabled, verify a user's records are readable only under their UID
  and anonymous writes are denied.

Offline checks run every five minutes. Emulator scheduled triggers may not run
automatically; verify offline alert creation using scheduled trigger support or
a Blaze deployment.
